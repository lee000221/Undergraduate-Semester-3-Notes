
package Function;

import ObjectClass.Administrator;
import ObjectClass.Catalogue;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Calendar;

public class Startup {
    
    public static void Startup(){
        Administrator a = new Administrator(1, "Poong", "Parkhill Residence", "tp053138@mail.apu.edu.my", "master", "master");
        try{
            PrintWriter p = new PrintWriter("admin.txt");
            p.println(a.getAID());
            p.println(a.getsName());
            p.println(a.getAddress());
            p.println(a.getEmail());
            p.println(a.getLoginName());
            p.println(a.getPassword());
            p.println();
            p.close();
        } catch (Exception e){}
    }
    
    public static void createFile(String filename){
        try{
            FileWriter f = new FileWriter(filename);
            f.close();
        } catch (Exception e){}
    }

}
