
package Function;

public class CatalogueItem {
    private int CatalagueReference, ProductID;
    public CatalogueItem(int CatalogueReference, int ProductID){
        this.CatalagueReference = CatalogueReference;
        this.ProductID = ProductID;
    }

    public int getCatalagueReference() {
        return CatalagueReference;
    }

    public int getProductID() {
        return ProductID;
    }
    
}
