
package Function;

import ObjectClass.Administrator;
import ObjectClass.Catalogue;
import ObjectClass.ProductItem;
import ObjectClass.ProductManager;
import ObjectClass.Supplier;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class ImportFile {
    public static ArrayList<Administrator> allAdmin;
    public static ArrayList<ProductManager> allProManager;
    public static ArrayList<Supplier> allSupplier;
    public static ArrayList<ProductItem> allProduct;
    public static ArrayList<Catalogue> allCatalogue;
    public static ArrayList<CatalogueItem> allCatItem = new ArrayList<CatalogueItem>();
    
    public static void importAdmin(){
        allAdmin = new ArrayList<Administrator>();
        File tempFile = new File("C:\\Users\\Asus\\OneDrive\\Year 2 Sem 1\\Object Oriented Development with Java\\Assignment\\ProductCatalogueManagement System\\admin.txt");
        boolean exists = tempFile.exists();
        if (exists == true){
            try{
                Scanner s1 = new Scanner (new File("admin.txt"));
                while (s1.hasNext()){
                    int AID = Integer.parseInt(s1.nextLine());
                    String sName = s1.nextLine();
                    String address = s1.nextLine();
                    String email = s1.nextLine();
                    String loginName = s1.nextLine();
                    String password = s1.nextLine();
                    s1.nextLine();
                    Administrator A = new Administrator (AID, sName, address, email, loginName, password);
                    allAdmin.add(A);
                }
            } catch (Exception e){
                JOptionPane.showInputDialog("Error !");
                e.printStackTrace();
            }
        } else {
            Startup.Startup();
        }
        
    }
    
    public static void importProManager(){
        allProManager = new ArrayList<ProductManager>();
        File tempFile = new File("C:\\Users\\Asus\\OneDrive\\Year 2 Sem 1\\Object Oriented Development with Java\\Assignment\\ProductCatalogueManagement System\\promanager.txt");
        boolean exists = tempFile.exists();
        if (exists == true){
            try{
                Scanner s1 = new Scanner (new File("promanager.txt"));
                while (s1.hasNext()){
                    int PMID = Integer.parseInt(s1.nextLine());
                    String sName = s1.nextLine();
                    String address = s1.nextLine();
                    String email = s1.nextLine();
                    String loginName = s1.nextLine();
                    String password = s1.nextLine();
                    String status =s1.nextLine();
                    s1.nextLine();
                    ProductManager PM = new ProductManager (PMID, sName, address, email, loginName, password, Boolean.parseBoolean(status));
                    allProManager.add(PM);
                }
            } catch (Exception e){
                JOptionPane.showInputDialog("Error !");
                e.printStackTrace();
            }
        } else {
            String file = "promanager.txt";
            Startup.createFile(file);
        }
    }
        
    public static void importSupplier(){
        allSupplier = new ArrayList<Supplier>();
        File tempFile = new File("C:\\Users\\Asus\\OneDrive\\Year 2 Sem 1\\Object Oriented Development with Java\\Assignment\\ProductCatalogueManagement System\\supplier.txt");
        boolean exists = tempFile.exists();
        if (exists == true){
            try{
                Scanner s1 = new Scanner (new File("supplier.txt"));
                while (s1.hasNext()){
                    int suID = Integer.parseInt(s1.nextLine());
                    String suName = s1.nextLine();
                    String suAdd = s1.nextLine();
                    String status = s1.nextLine();
                    s1.nextLine();
                    Supplier SU = new Supplier(suID,suName,suAdd,Boolean.parseBoolean(status));
                    allSupplier.add(SU);
                }
            } catch (Exception e){
                JOptionPane.showInputDialog("Error !");
                e.printStackTrace();
            }
        } else {
            String file = "supplier.txt";
            Startup.createFile(file);
        }
        
    }
    
    
    public static void importProduct(){
        allProduct = new ArrayList<ProductItem>();
        File tempFile = new File("C:\\Users\\Asus\\OneDrive\\Year 2 Sem 1\\Object Oriented Development with Java\\Assignment\\ProductCatalogueManagement System\\product.txt");
        boolean exists = tempFile.exists();
        if (exists == true){
            try{
                Scanner s1 = new Scanner (new File("product.txt"));
                while (s1.hasNext()){
                    int PID = Integer.parseInt(s1.nextLine());
                    String pName = s1.nextLine();
                    double price = Double.parseDouble(s1.nextLine());
                    String description = s1.nextLine();
                    String category = s1.nextLine();
                    String supplier = s1.nextLine();
//                    String rn = s1.nextLine();
                    s1.nextLine();
//                    Catalogue catalogue = null;
//                    for (int i=0; i<allCatalogue.size(); i++){
//                        Catalogue C = allCatalogue.get(i);
//                        if (rn.equals(C.getReferenceNum())){
//                            catalogue = C;
//                            break;
//                        }
//                    }
                    ProductItem PI = new ProductItem(PID, pName, price, description, category, supplier);
//                    catalogue.myProduct.add(PI);
                    allProduct.add(PI);
                }
            } catch (Exception e){
                JOptionPane.showInputDialog("Error !");
                e.printStackTrace();
            }
        } else {
            String file = "product.txt";
            Startup.createFile(file);
        }

    }
    
    public static void importCatalogue(){
        allCatalogue = new ArrayList<Catalogue>();
        File tempFile = new File("C:\\Users\\Asus\\OneDrive\\Year 2 Sem 1\\Object Oriented Development with Java\\Assignment\\ProductCatalogueManagement System\\catalogue.txt");
        boolean exists = tempFile.exists();
        if (exists == true){
            try{
                Scanner s1 = new Scanner (new File("catalogue.txt"));
                while (s1.hasNext()){
                    int referenceNum = Integer.parseInt(s1.nextLine());
                    String title = s1.nextLine();
                    String description = s1.nextLine();
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy");
                    Date Startdate = dateFormat.parse(s1.nextLine());
                    Date Enddate = dateFormat.parse(s1.nextLine());
                    String name =s1.nextLine();
                    String createtime = s1.nextLine();
                    s1.nextLine();
                    ProductManager creator = null;
                    for (int i=0; i<allProManager.size(); i++){
                        ProductManager PM = allProManager.get(i);
                        if (name.equals(PM.getsName())){
                            creator = PM;
                            break;
                        }
                    }
                    Catalogue CATA = new Catalogue(referenceNum, title, description, Startdate, Enddate, creator, createtime);
                    creator.getMyCatalogue().add(CATA);
                    allCatalogue.add(CATA);
                }
            } catch (Exception e){
                JOptionPane.showInputDialog("Error !");
                e.printStackTrace();
            }
        } else {
            String file = "catalogue.txt";
            Startup.createFile(file);
        }
    }
    
    public static void importCatalogueItem(){
//        allCatItem = new ArrayList<CatalogueItem>();
        File tempFile = new File("C:\\Users\\Asus\\OneDrive\\Year 2 Sem 1\\Object Oriented Development with Java\\Assignment\\ProductCatalogueManagement System\\catalogueitem.txt");
        boolean exists = tempFile.exists();
        if(exists == true){
            try{
                Scanner s1 = new Scanner (new File("catalogueitem.txt"));
                while (s1.hasNext()){
                    int referenceNum = Integer.parseInt(s1.nextLine());
                    int productID = Integer.parseInt(s1.nextLine());
                    s1.nextLine();
                    CatalogueItem CI = new CatalogueItem(referenceNum, productID);
                    allCatItem.add(CI);
                }
                 
                
            } catch (Exception e){
                JOptionPane.showInputDialog("Error");
                e.printStackTrace();
            }
        } else {
            String file = "catalogueitem.txt";
            Startup.createFile(file);
        }
    }
}
