
package GUI;

import static Function.ImportFile.allProduct;
import static Function.ImportFile.allSupplier;
import ObjectClass.ProductItem;
import ObjectClass.Supplier;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.nio.file.Files.size;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class AddProduct extends JFrame implements ActionListener {
    
        private JLabel addinfo = new JLabel("Please Enter the Product Information :");
        
        
        
        private JLabel pname = new JLabel("Product Name: ");
	private JTextField Pname = new JTextField(20);
        
	private JLabel pri = new JLabel("Product Price: ");
	private JTextField Pri = new JTextField(20);
        
        private JLabel des = new JLabel("Product Description: ");
	private JTextField Des = new JTextField(20);
        
        JLabel kind =new JLabel("Product Category: ");
        public String[] CatChoices(){
            String[] str= {"Food & Drinks","Electronics","Household Tools","Medicine"};
            return str;
        }
        String[] Cchoice = CatChoices();
	JComboBox cate = new JComboBox(Cchoice);
        
        JLabel sup = new JLabel("Supplier: ");
        public static String[] SupChoices(){
            String[] str= new String[allSupplier.size()];
            for (int i=0; i<allSupplier.size(); i++) {
                Supplier SU = allSupplier.get(i);
                str[i]= String.valueOf(SU.getSuName());
            }
            return str;
        }
        String[] SUchoice = SupChoices();
        JComboBox Sup = new JComboBox(SUchoice);

	private JButton addinfo1 = new JButton("Add");
	private JButton addinfo2 = new JButton("Previous Page");
	private JButton addinfo3 = new JButton("Quit");
        
        public AddProduct(){
           this.setTitle("Add Product Information"); 
           this.setBounds(10,10,450,550);
           this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           this.setLayout(null);
           
       
           
           pname.setBounds(80,120,100,20);
           this.add(pname);		
           Pname.setBounds(210,120,120,20);
	   this.add(Pname);
           
           pri.setBounds(80,160,120,20);
           this.add(pri);		
           Pri.setBounds(210,160,120,20);
	   this.add(Pri);  
           
           
           des.setBounds(80,200,120,20);
           this.add(des);	
           
           Des.setBounds(210,200,120,20);
	   this.add(Des);   
           
 
           kind.setBounds(80,240,120,20);
           this.add(kind);	
           cate.setBounds(210,240,120,20);
	   this.add(cate);  
           cate.addActionListener(this);     
           
           sup.setBounds(80,360,100,20);
           this.add(sup);		
           Sup.setBounds(210,360,120,20);
	   this.add(Sup);             
           
           
           addinfo.setBounds(5,15,230,40);
           this.add(addinfo);
           
           addinfo1.setBounds(150,420,125,20);
           this.add(addinfo1);
           addinfo1.addActionListener(this);  
           
           addinfo2.setBounds(80,460,125,20);
           this.add(addinfo2);
           addinfo2.addActionListener(this);
           
           addinfo3.setBounds(215,460,125,20);
           this.add(addinfo3);
           addinfo3.addActionListener(this);
           
           this.setVisible(false);
        }
        

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == addinfo1){
                int number;
                int size = allProduct.size();
                if(allProduct.size() == 0){
                number = 10001;
                }else{
                number = allProduct.get(size - 1).getPID() + 1;
                }
                String Pid = String.valueOf(number);
                String Pname = this.Pname.getText();
                String Pprice = Pri.getText();
                String Pdes = Des.getText();
                String Pcat = cate.getSelectedItem().toString();
                String Psup = Sup.getSelectedItem().toString();
                ProductItem.addProduct(Pid, Pname, Pprice, Pdes, Pcat, Psup);
            } else if (ae.getSource() == addinfo2){
                ProductCatalogueManagementSystem.page4.setVisible(true);
                ProductCatalogueManagementSystem.page10.setVisible(false);
            } else if (ae.getSource() == addinfo3){
                System.exit(0);
            }
        }

        
}


