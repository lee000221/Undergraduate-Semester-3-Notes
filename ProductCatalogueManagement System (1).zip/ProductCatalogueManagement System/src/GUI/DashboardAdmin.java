
package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;


public class DashboardAdmin extends JFrame implements ActionListener{
	private JMenu ad;
        private JButton ad1,ad2,ad3,ad4,ad5,ad6;
        public DashboardAdmin(){
           this.setTitle("Welcome,Dear.Admin!"); 
           this.setBounds(10,10,550,330);
           this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           this.setLayout(null);
           
           ad=new JMenu("Administrator Dashboard");
           ad1=new JButton("Manage Product");
           ad2=new JButton("Manage Product Manager");
           ad3=new JButton("Manage Supplier");
           ad4=new JButton("Manage Administrator");
           ad5=new JButton("Previous Page");
           ad6=new JButton("Quit");
           
           ad.setBounds(15,40,170,40);
           this.add(ad);
           
           ad1.setBounds(40,100,200,20);
           this.add(ad1);
           ad1.addActionListener(this);
           
           ad2.setBounds(280,100,200,20);
           this.add(ad2);
           ad2.addActionListener(this);
           
           ad3.setBounds(40,150,200,20);
           this.add(ad3);
           ad3.addActionListener(this);
           
           ad4.setBounds(280,150,200,20);
           this.add(ad4);
           ad4.addActionListener(this);
           
           ad5.setBounds(130,220,125,20);
           this.add(ad5);
           ad5.addActionListener(this);
           
           ad6.setBounds(255,220,125,20);
           this.add(ad6);
           ad6.addActionListener(this);
           
           this.setVisible(false);

          
        }
                   

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource()== ad1){
            ProductCatalogueManagementSystem.page4.setVisible(true);
            ProductCatalogueManagementSystem.page2.setVisible(false);
        } else if (ae.getSource()== ad2){
            ProductCatalogueManagementSystem.page5.setVisible(true);
            ProductCatalogueManagementSystem.page2.setVisible(false);
        } else if (ae.getSource()== ad3){
            ProductCatalogueManagementSystem.page6.setVisible(true);
            ProductCatalogueManagementSystem.page2.setVisible(false);
        } else if (ae.getSource()== ad4){
            ProductCatalogueManagementSystem.page7.setVisible(true);
            ProductCatalogueManagementSystem.page2.setVisible(false);
        } else if (ae.getSource()== ad5){
            ProductCatalogueManagementSystem.page1.setVisible(true);
            ProductCatalogueManagementSystem.page2.setVisible(false);
        } else if (ae.getSource()== ad6){
            System.exit(0);
        }
    }

}

