
package GUI;

import static Function.ImportFile.allSupplier;
import ObjectClass.Supplier;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class AddProSupplier extends JFrame implements ActionListener {
    
        private JLabel addsup = new JLabel("Please Enter the Supplier Information : ");

 
        
        private JLabel sname = new JLabel("Name: ");
	private JTextField Sname = new JTextField(20);
        
        private JLabel sadd = new JLabel("Address: ");
	private JTextField Sadd = new JTextField(20);

	private JButton addsup1 = new JButton("Add");
	private JButton addsup2 = new JButton("Previous Page");
	private JButton addsup3 = new JButton("Quit");
        
        public AddProSupplier(){
           this.setTitle("Add Product Supplier Information"); 
           this.setBounds(10,10,400,400);
           this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           this.setLayout(null);
           

           
           sname.setBounds(50,120,100,20);
           this.add(sname);		
           Sname.setBounds(120,120,120,20);
	   this.add(Sname);
           
           sadd.setBounds(50,160,100,20);
           this.add(sadd);		
           Sadd.setBounds(120,160,120,20);
	   this.add(Sadd);
        
           addsup.setBounds(5,10,250,80);
           this.add(addsup);
           
 
           addsup1.setBounds(120,200,100,20);
           this.add(addsup1);
           addsup1.addActionListener(this);  
           
           addsup2.setBounds(40,240,120,20);
           this.add(addsup2);
           addsup2.addActionListener(this);
           
           addsup3.setBounds(175,240,120,20);
           this.add(addsup3);
           addsup3.addActionListener(this);
           
           this.setVisible(false);
        }


        @Override
        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == addsup1){
                int number;
                int size = allSupplier.size();
                if(allSupplier.size() == 0){
                number = 1001;
                }else{
                number = allSupplier.get(size - 1).getIntSuID() + 1;
                }
                String Sid = String.valueOf(number);
                String Sname = this.Sname.getText();
                String Sadd = this.Sadd.getText();
                Supplier.addSupplier(Sid, Sname, Sadd);
            } else if (ae.getSource() == addsup2){
                ProductCatalogueManagementSystem.page6.setVisible(true);
                ProductCatalogueManagementSystem.page12.setVisible(false);
            } else if (ae.getSource() == addsup3){
                System.exit(0);
            }
        }
}





