
package GUI;

import Function.CatalogueItem;
import Function.ImportFile;
import static Function.ImportFile.allCatItem;
import static Function.ImportFile.allCatalogue;
import static Function.ImportFile.allProduct;
import ObjectClass.Catalogue;
import static ObjectClass.Catalogue.getMyProduct;
import ObjectClass.ProductItem;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class ManageCatItem extends JFrame implements ActionListener{
    private JLabel a = new JLabel("Catalogue Reference Number:");
    private static JLabel A = new JLabel();
    private JButton b1 = new JButton("Add");
    private JButton b2 = new JButton("Remove");
    public static DefaultTableModel zc;
    public static DefaultTableModel zc2;
    public static JTable zc1;
    public static JTable zc3;
    private JPanel P1 = new JPanel();
    private JPanel P2 = new JPanel();

    public static JLabel getA() {
        return A;
    }

    
    
    public ManageCatItem(){


        
        this.setTitle("Manage Catalogue Items"); 
        this.setBounds(10,10,900,550);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
           
        int size = allProduct.size();
        String[][] data = new String[size][3];
        for (int i=0; i<size; i++){
        ProductItem P = ImportFile.allProduct.get(i);
        data[i][0] = Integer.toString(P.getPID());
        data[i][1] = P.getpName();
        data[i][2] = Double.toString(P.getPrice());
        }
        String[] columnNames = {"ID","Name","Price"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        zc = new DefaultTableModel (data, columnNames){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        zc1 = new JTable(zc);
        zc1.setPreferredScrollableViewportSize(new Dimension(230, 100));
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS; 
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
        JScrollPane sp = new JScrollPane(zc1,v,h);
        zc1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        zc1.setDefaultRenderer(Object.class, centerRenderer);
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(zc1.getModel());
        zc1.setRowSorter(rowSorter);
        for (int i=2; i<=zc.getRowCount(); i++){
            for (int j=1; j<=zc.getColumnCount(); j++){
                zc.isCellEditable(i, j);
            }
        }

        Catalogue CT = new Catalogue();
        for (int i=0; i<allCatalogue.size(); i++){
            Catalogue temp = allCatalogue.get(i);
            if (A.getText() == String.valueOf(temp.getReferenceNum())){
                CT = temp;
            }
        }
        
        int size2 = CT.getMyProduct().size();
        String[][] data2 = new String[size2][3];
        for (int i=0; i<size2; i++){
        ProductItem P1 = CT.getMyProduct().get(i);
        data[i][0] = Integer.toString(P1.getPID());
        data[i][1] = P1.getpName();
        data[i][2] = Double.toString(P1.getPrice());
        }
        String[] columnNames1 = {"ID","Name","Price"};
        DefaultTableCellRenderer centerRenderer1 = new DefaultTableCellRenderer();
        centerRenderer1.setHorizontalAlignment( JLabel.CENTER );
        zc2 = new DefaultTableModel (data2, columnNames1){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        zc3 = new JTable(zc2);
        zc3.setPreferredScrollableViewportSize(new Dimension(230, 100));
        int v1 = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS; 
        int h1 = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
        JScrollPane sp1 = new JScrollPane(zc3,v1,h1);
        zc3.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        zc3.setDefaultRenderer(Object.class, centerRenderer);
        TableRowSorter<TableModel> rowSorter1 = new TableRowSorter<>(zc3.getModel());
        zc3.setRowSorter(rowSorter1);
        for (int i=2; i<=zc2.getRowCount(); i++){
            for (int j=1; j<=zc2.getColumnCount(); j++){
                zc2.isCellEditable(i, j);
            }
        }
        
        P1.add(sp);
        P1.setBounds(80,180,400,150);
        this.add(P1);
        
        P2.add(sp1);
        P2.setBounds(180,180,900,150);
        this.add(P2);
        
        a.setBounds(370,50,300,20);
        this.add(a);
        
        A.setBounds(450,80,100,20);
        this.add(A);
        
        b1.setBounds(220,150,120,20);
        this.add(b1);
        b1.addActionListener(this);
        
        b2.setBounds(570,150,120,20);
        this.add(b2);
        b2.addActionListener(this);
        
        this.setVisible(false);   
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == b1){
            Catalogue C = new Catalogue();
            for (int i=0; i<allCatalogue.size(); i++){
                Catalogue temp = allCatalogue.get(i);
                if (Integer.parseInt(A.getText()) == temp.getReferenceNum()){
                    C = temp;
                }
            }
            
            int referenceNum = C.getReferenceNum();
            int row = zc1.getSelectedRow();
            int productID = Integer.parseInt(zc1.getValueAt(row, 0).toString());

            ProductItem P = new ProductItem();
            for (int i=0; i<allProduct.size(); i++){
                ProductItem temp = allProduct.get(i);
                if (productID == temp.getPID()){
                    P = temp;
                }
            }       
            
 
            CatalogueItem newCI = new CatalogueItem(referenceNum, productID);
            allCatItem = new ArrayList<CatalogueItem>();
            allCatItem.add(newCI);
            try {
                    PrintWriter p = new PrintWriter("catalogueitem.txt");
                    for (int i=0 ; i< ImportFile.allCatItem.size(); i++){
                        CatalogueItem CI =  ImportFile.allCatItem.get(i);
                        p.println(CI.getCatalagueReference());
                        p.println(CI.getProductID());
                        p.println();
                    }
                    p.close();
            } catch (Exception ex){
                ex.printStackTrace();
            }
            
            C.getMyProduct().add(P);
            DefaultTableModel model= (DefaultTableModel)ManageCatItem.zc3.getModel();
            model.addRow(new Object[]{P.getPID(),P.getpName(),P.getPrice()});
        } else if(e.getSource() == b2){
            
        }
    }
    

}
