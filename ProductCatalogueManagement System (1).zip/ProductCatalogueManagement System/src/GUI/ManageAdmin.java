
package GUI;

import Function.ImportFile;
import static Function.ImportFile.allAdmin;
import ObjectClass.Administrator;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.PrintWriter;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.DocumentListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class ManageAdmin extends JFrame implements ActionListener, MouseListener, TableModel{

    private JLabel sakw = new JLabel("Search:");
    private JTextField Sakw = new JTextField();
    private JLabel aid = new JLabel("ID: ");
    private JTextField Aid = new JTextField(20);
        
    private JLabel aname = new JLabel("Name: ");
    private JTextField Aname = new JTextField(20);
        
    private JLabel aadd = new JLabel("Address: ");
    private JTextField Aadd = new JTextField(20);
        
    private JLabel aemail = new JLabel("Email: ");
    private JTextField Aemail = new JTextField(20);
        

    private JLabel aun = new JLabel("Username: ");
    private JTextField Aun = new JTextField(20);
        
    private JLabel apsw = new JLabel("Password: ");
    private JTextField Apsw = new JTextField(20);
    
    private JButton sa2 = new JButton("Add");
    private JButton sa3 = new JButton("Delete");
    private JButton sa4 = new JButton("Edit");
    private JButton sa5 = new JButton("Previous Page");
    private JButton sa6 = new JButton("Quit");
   
    public static DefaultTableModel z;
    public static JTable z1;
    private JPanel P1 = new JPanel();
    private String temp;


    
    public ManageAdmin() {
        this.setTitle("Search Administrator Information"); 
        this.setBounds(10,10,900,550);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        
        int size = allAdmin.size();
        String[][] data = new String[size][6];
        for (int i=0; i<size; i++){
        Administrator A = ImportFile.allAdmin.get(i);
        data[i][0] = A.getAID();
        data[i][1] = A.getsName();
        data[i][2] = A.getAddress();
        data[i][3] = A.getEmail();
        data[i][4] = A.getLoginName();
        data[i][5] = A.getPassword();
        }
        String[] columnNames = {"ID","Name","Address","Email","Username","Password"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        z = new DefaultTableModel (data, columnNames){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        z1 = new JTable(z);
        z1.setPreferredScrollableViewportSize(new Dimension(350, 100));
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS; 
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
        JScrollPane sp = new JScrollPane(z1,v,h);
        z1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        z1.setDefaultRenderer(Object.class, centerRenderer);
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(z1.getModel());
        z1.setRowSorter(rowSorter);
        for (int i=2; i<=z.getRowCount(); i++){
            for (int j=1; j<=z.getColumnCount(); j++){
                z.isCellEditable(i, j);
            }
        }
        P1.add(sp);
        z1.addMouseListener(this); 
        Sakw.getDocument().addDocumentListener(new DocumentListener(){
            
       
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                String text = Sakw.getText();
                
                if(text.trim().length() == 0){
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
            

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                String text = Sakw.getText();
                
                if(text.trim().length() == 0){
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        
 
           aid.setBounds(530,80,100,20);
           this.add(aid);		
           Aid.setBounds(610,80,120,20);
	   this.add(Aid);
           
           aname.setBounds(530,120,100,20);
           this.add(aname);		
           Aname.setBounds(610,120,120,20);
	   this.add(Aname);
           
           aadd.setBounds(530,160,120,20);
           this.add(aadd);		
           Aadd.setBounds(610,160,120,20);
	   this.add(Aadd);  
           
           
           aemail.setBounds(530,200,120,20);
           this.add(aemail);	
           Aemail.setBounds(610,200,120,20);
	   this.add(Aemail);   
           
 
        
           aun.setBounds(530,300,100,20);
           this.add(aun);		
           Aun.setBounds(610,300,120,20);
	   this.add(Aun);  
           
           apsw.setBounds(530,340,100,20);
           this.add(apsw);		
           Apsw.setBounds(610,340,120,20);
	   this.add(Apsw);       
        
           sakw.setBounds(120,30,200,20);
           this.add(sakw);		
           Sakw.setBounds(280,30,120,20);
	   this.add(Sakw);
           

           
           sa2.setBounds(100,420,120,20);
	   this.add(sa2); 
           sa2.addActionListener(this);
           sa3.setBounds(215,420,120,20);
           this.add(sa3);
           sa3.addActionListener(this);
           sa4.setBounds(335,420,120,20);
	   this.add(sa4);   
           sa4.addActionListener(this);
           
 
           sa5.setBounds(140,450,120,20);
           this.add(sa5);
           sa5.addActionListener(this);
           sa6.setBounds(270,450,120,20);
	   this.add(sa6); 
           sa6.addActionListener(this);

           P1.setBounds(80,180,400,600);
           this.add(P1);
           
           this.setVisible(false);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == sa2){
            ProductCatalogueManagementSystem.page13.setVisible(true);
            ProductCatalogueManagementSystem.page7.setVisible(false);
        } else if (ae.getSource() == sa3){
            if (Aid.getText().isEmpty()){
                JOptionPane.showMessageDialog(sa3, "Please Select Admin");
            } else{
                try{
                    PrintWriter p1 = new PrintWriter("admin.txt");
                    for(int i=0; i<allAdmin.size(); i++){
                        Administrator A = allAdmin.get(i);
                        if(A.getAID().equals(Aid.getText())){
                            DefaultTableModel model = (DefaultTableModel) z1.getModel();
                            model.removeRow(i);
                        } else {
                            p1.println(A.getAID());
                            p1.println(A.getsName());
                            p1.println(A.getAddress());
                            p1.println(A.getEmail());
                            p1.println(A.getLoginName());
                            p1.println(A.getPassword());
                            p1.println();
                        }
                    } 
                            p1.close();
                }catch(Exception e){}
                
            }                  
        } else if (ae.getSource() == sa4){
            if (Aid.getText().isEmpty()){
                JOptionPane.showMessageDialog(sa4, "Please Select Admin");
            } else{
                String newAdd = Aadd.getText();
                String newEmail = Aemail.getText();
                String newPw = Apsw.getText();
                try{
                    PrintWriter p1 = new PrintWriter("admin.txt");
                    for(int i=0; i<allAdmin.size(); i++){
                        Administrator A = allAdmin.get(i);
                        if(A.getAID().equals(Aid.getText())){
                            p1.println(A.getAID());
                            p1.println(A.getsName());
                            A.setAddress(newAdd);
                            A.setEmail(newEmail);
                            A.setPassword(newPw);
                            p1.println(A.getAddress());
                            p1.println(A.getEmail());
                            p1.println(A.getLoginName());
                            p1.println(A.getPassword());
                            p1.println();
                            DefaultTableModel model = (DefaultTableModel) z1.getModel();
                            model.setValueAt(newAdd,i,2);
                            model.setValueAt(newEmail,i,3);
                            model.setValueAt(newPw,i,5);
                        } else {
                            p1.println(A.getAID());
                            p1.println(A.getsName());
                            p1.println(A.getAddress());
                            p1.println(A.getEmail());
                            p1.println(A.getLoginName());
                            p1.println(A.getPassword());
                            p1.println();
                        }
                    } 
                            p1.close();
                }catch(Exception e){}      
                JOptionPane.showMessageDialog(sa4,"Successful");
            }    
            
            int size = allAdmin.size();
            String[][] data = new String[size][6];
            for (int i=0; i<size; i++){
            Administrator A = ImportFile.allAdmin.get(i);
            data[i][0] = A.getAID();
            data[i][1] = A.getsName();
            data[i][2] = A.getAddress();
            data[i][3] = A.getEmail();
            data[i][4] = A.getLoginName();
            data[i][5] = A.getPassword();
            }
            String[] columnNames = {"ID","Name","Address","Email","Username","Password"};
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment( JLabel.CENTER );
            z = new DefaultTableModel (data, columnNames);
        } else if (ae.getSource() == sa5){
            ProductCatalogueManagementSystem.page2.setVisible(true);
            ProductCatalogueManagementSystem.page7.setVisible(false);
        } else if (ae.getSource() == sa6){
            System.exit(0);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {                                          
        int row = z1.rowAtPoint(e.getPoint());
        String temp[]= new String[6];
        for (int i=0; i<6; i++){
            z1.getValueAt(row, i);
            temp[i] = (String)z1.getValueAt(row, i);
            } 
        Aid.setText(temp[0]);
        Aid.setEditable(false);
        Aname.setText(temp[1]);
        Aname.setEditable(false);
        Aadd.setText(temp[2]);
        Aemail.setText(temp[3]);
        Aun.setText(temp[4]);
        Aun.setEditable(false);
        Apsw.setText(temp[5]);
    }
    
    @Override
    public void mousePressed(MouseEvent e2) {}

    @Override
    public void mouseReleased(MouseEvent e3) {}
        
    @Override
    public void mouseEntered(MouseEvent e4) {}
        
    @Override
    public void mouseExited(MouseEvent e5) {}

    @Override
    public int getRowCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getColumnCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getColumnName(int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void addTableModelListener(TableModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    



    
}   
