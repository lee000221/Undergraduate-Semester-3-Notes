
package GUI;

import Function.ImportFile;
import static Function.ImportFile.allAdmin;
import static Function.ImportFile.allProduct;
import static Function.ImportFile.allSupplier;
import static GUI.ManageAdmin.z;
import static GUI.ManageAdmin.z1;
import ObjectClass.Administrator;
import ObjectClass.ProductItem;
import ObjectClass.Supplier;
import java.awt.Dimension;
import static java.awt.PageAttributes.MediaType.A;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.PrintWriter;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.DocumentListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class ManageProduct extends JFrame implements ActionListener, MouseListener, TableModel{

    
    private JLabel kw = new JLabel("Enter the keyword :");
    private JTextField Kw = new JTextField();	
    
    private JButton s2 = new JButton("Add");
    private JButton s3 = new JButton("Delete");
    private JButton s4 = new JButton("Edit");
    private JButton s5 = new JButton("Previous Page");
    private JButton s6 = new JButton("Quit");
        
        private JLabel no = new JLabel("Product ID: ");
	private JTextField No = new JTextField(20);
        
        private JLabel pname = new JLabel("Name: ");
	private JTextField Pname = new JTextField(20);//set plain text
        
	private JLabel pri = new JLabel("Price: ");
	private JTextField Pri = new JTextField(20);
        
        private JLabel des = new JLabel("Description: ");
	private JTextField Des = new JTextField(20);
        
        JLabel kind =new JLabel("Category: ");
        private JTextField Cat = new JTextField(20);
        
        JLabel sup = new JLabel("Supplier: ");
        private JTextField Sup = new JTextField(20);
    
    public static DefaultTableModel zc;
    public static JTable zc1;
    private JPanel P1 = new JPanel();
    private String temp;
    
    public ManageProduct() {
        this.setTitle("Search Product Information"); 
        this.setBounds(10,10,900,550);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
           
        int size = allProduct.size();
        String[][] data = new String[size][6];
        for (int i=0; i<size; i++){
        ProductItem P = ImportFile.allProduct.get(i);
        data[i][0] = Integer.toString(P.getPID());
        data[i][1] = P.getpName();
        data[i][2] = Double.toString(P.getPrice());
        data[i][3] = P.getDescription();
        data[i][4] = P.getCategory();
        data[i][5] = P.getSupplier();
        }
        String[] columnNames = {"ID","Name","Price","Description","Category","Supplier"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        zc = new DefaultTableModel (data, columnNames){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        zc1 = new JTable(zc);
        zc1.setPreferredScrollableViewportSize(new Dimension(350, 100));
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS; 
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
        JScrollPane sp = new JScrollPane(zc1,v,h);
        zc1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        zc1.setDefaultRenderer(Object.class, centerRenderer);
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(zc1.getModel());
        zc1.setRowSorter(rowSorter);
        for (int i=2; i<=zc.getRowCount(); i++){
            for (int j=1; j<=zc.getColumnCount(); j++){
                zc.isCellEditable(i, j);
            }
        }
        P1.add(sp);
        zc1.addMouseListener(this); 
        Kw.getDocument().addDocumentListener(new DocumentListener(){
            
       
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                String text = Kw.getText();
                
                if(text.trim().length() == 0){
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
            

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                String text = Kw.getText();
                
                if(text.trim().length() == 0){
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        no.setBounds(530,80,100,20);
           this.add(no);		
           No.setBounds(610,80,120,20);
	   this.add(No);
           
           pname.setBounds(530,120,100,20);
           this.add(pname);		
           Pname.setBounds(610,120,120,20);
	   this.add(Pname);
           
           pri.setBounds(530,160,120,20);
           this.add(pri);		
           Pri.setBounds(610,160,120,20);
	   this.add(Pri);  
           
           
           des.setBounds(530,200,120,20);
           this.add(des);	
           
           Des.setBounds(610,200,120,20);
	   this.add(Des);   
           
 
           kind.setBounds(530,240,120,20);
           this.add(kind);	
           Cat.setBounds(610,240,120,20);
	   this.add(Cat);  
               
           
           sup.setBounds(530,360,100,20);
           this.add(sup);		
           Sup.setBounds(610,360,120,20);
	   this.add(Sup);             
        
           
           kw.setBounds(100,70,150,20);
           this.add(kw);		
           Kw.setBounds(230,70,120,20);
	   this.add(Kw);
           
           
           s2.setBounds(60,420,120,20);
	   this.add(s2);  
           s2.addActionListener(this);
           
           s3.setBounds(180,420,120,20);
           this.add(s3);
           s3.addActionListener(this);
           
           s4.setBounds(300,420,120,20);
	   this.add(s4);   
           s4.addActionListener(this);
 
           s5.setBounds(100,450,120,20);
           this.add(s5);
           s5.addActionListener(this);
           
           s6.setBounds(230,450,120,20);
	   this.add(s6);  
           s6.addActionListener(this);

           P1.setBounds(80,180,400,600);
           this.add(P1);
           
           this.setVisible(false);
    }

    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == s2){
            ProductCatalogueManagementSystem.page10.setVisible(true);
            ProductCatalogueManagementSystem.page4.setVisible(false);
        } else if (ae.getSource() == s3){
            if (No.getText().isEmpty()){
                JOptionPane.showMessageDialog(s3, "Please Select Product");
            } else{
                try{
                    PrintWriter p1 = new PrintWriter("product.txt");
                    for(int i=0; i<allProduct.size(); i++){
                        ProductItem P = allProduct.get(i);
                        if(Integer.toString(P.getPID()).equals(No.getText())){
                            DefaultTableModel model = (DefaultTableModel) zc1.getModel();
                            model.removeRow(i);
                        } else {
                            p1.println(Integer.toString(P.getPID()));
                            p1.println(P.getpName());
                            p1.println(Double.toString(P.getPrice()));
                            p1.println(P.getDescription());
                            p1.println(P.getCategory());
                            p1.println(P.getSupplier());
                            p1.println();
                        }
                    } 
                            p1.close();
                }catch(Exception e){} 
            
            }                 
        } else if (ae.getSource() == s4){
            if (No.getText().isEmpty()){
                JOptionPane.showMessageDialog(s4, "Please Select Product");
            } else{
                String newPrice = Pri.getText();
                String newDes = Des.getText();
                String newSup = Sup.getText();
                try{
                    PrintWriter p1 = new PrintWriter("product.txt");
                    for(int i=0; i<allProduct.size(); i++){
                        ProductItem P = allProduct.get(i);
                        if(Integer.toString(P.getPID()).equals(No.getText())){
                            p1.println(P.getPID());
                            p1.println(P.getpName());
                            P.setPrice(Double.parseDouble(newPrice));
                            P.setDescription(newDes);
                            P.setSupplier(newSup);

                            p1.println(P.getPrice());
                            p1.println(P.getDescription());
                            p1.println(P.getCategory());
                            p1.println(P.getSupplier());
                            p1.println();
                            DefaultTableModel model = (DefaultTableModel) zc1.getModel();
                            model.setValueAt(newPrice,i,2);
                            model.setValueAt(newDes,i,3);
                            model.setValueAt(newSup,i,4);

                        } else {
                            p1.println(P.getPID());
                            p1.println(P.getpName());
                            p1.println(P.getPrice());
                            p1.println(P.getDescription());
                            p1.println(P.getCategory());
                            p1.println(P.getSupplier());
                            p1.println();
                        }
                    } 
                            p1.close();
                }catch(Exception e){}      
                JOptionPane.showMessageDialog(s4,"Successful");
            }
        int size = allProduct.size();
        String[][] data = new String[size][6];
        for (int i=0; i<size; i++){
        ProductItem P = ImportFile.allProduct.get(i);
        data[i][0] = Integer.toString(P.getPID());
        data[i][1] = P.getpName();
        data[i][2] = Double.toString(P.getPrice());
        data[i][3] = P.getDescription();
        data[i][4] = P.getCategory();
        data[i][5] = P.getSupplier();
        }
        String[] columnNames = {"ID","Name","Price","Description","Category","Supplier"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        zc = new DefaultTableModel (data, columnNames);
        } else if (ae.getSource() == s5){
            ProductCatalogueManagementSystem.page2.setVisible(true);
            ProductCatalogueManagementSystem.page4.setVisible(false);
        } else if (ae.getSource() == s6){
            System.exit(0);
        }
    }



    @Override
    public void mouseClicked(MouseEvent e) {
        int row = z1.rowAtPoint(e.getPoint());
        String temp[]= new String[6];
        for (int i=0; i<6; i++){
            zc1.getValueAt(row, i);
            temp[i] = (String)zc1.getValueAt(row, i);
            } 
        No.setText(temp[0]);
        No.setEditable(false);
        Pname.setText(temp[1]);
        Pname.setEditable(false);
        Pri.setText(temp[2]);
        Des.setText(temp[3]);
        Cat.setText(temp[4]);
        Cat.setEditable(false);
        Sup.setText(temp[5]);
        Sup.setEditable(false);
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
       
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public int getRowCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getColumnCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getColumnName(int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void addTableModelListener(TableModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    }

   