package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;


public class DashboardManager extends JFrame implements ActionListener{
	private JMenu md;
        private JButton md1,md2,md3,md4;
        public DashboardManager(){
           this.setTitle("Welcome,Dear.Manager!"); 
           this.setBounds(10,10,550,330);
           this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           this.setLayout(null);
           
           md=new JMenu("Product Manager Dashboard");
           md1=new JButton("Manage Catalogue");
           md2=new JButton("Manage Personal Profile");
           md3=new JButton("Previous Page");
           md4=new JButton("Quit");
           
           md.setBounds(15,30,190,40);
           this.add(md);
           
           md1.setBounds(150,100,200,20);
           this.add(md1);
           md1.addActionListener(this);
        
        
           md2.setBounds(150,150,200,20);
           this.add(md2);
           md2.addActionListener(this);  
           
           md3.setBounds(120,220,125,20);
           this.add(md3);
           md3.addActionListener(this);
           
           md4.setBounds(255,220,125,20);
           this.add(md4);
           md4.addActionListener(this);
           
           this.setVisible(false);

           
           
        }
                   


    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == md1){
            ProductCatalogueManagementSystem.page8.setVisible(true);
            ProductCatalogueManagementSystem.page3.setVisible(false);
        } else if (ae.getSource() == md2){
            ProductCatalogueManagementSystem.page9.setVisible(true);
            ProductCatalogueManagementSystem.page3.setVisible(false);
        } else if (ae.getSource() == md3){
            ProductCatalogueManagementSystem.page1.setVisible(true);
            ProductCatalogueManagementSystem.page3.setVisible(false);
        } else if (ae.getSource() == md4){
            System.exit(0);
        }
    }

}