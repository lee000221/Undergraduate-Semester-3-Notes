
package GUI;

import Function.ImportFile;
import static Function.ImportFile.allAdmin;
import static Function.ImportFile.allProManager;
import static GUI.ManageAdmin.z;
import static GUI.ManageAdmin.z1;
import ObjectClass.Administrator;
import ObjectClass.ProductManager;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.PrintWriter;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.DocumentListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class ManageProManager extends JFrame implements ActionListener, MouseListener, TableModel {

    private JLabel mkw = new JLabel("Enter the Manager ID :");
    private JTextField Mkw = new JTextField();
        
    private JLabel maccess = new JLabel("Product Manager Status : ");
        
    private JLabel mid = new JLabel("ID: ");
    private JTextField Mid = new JTextField(20);
        
    private JLabel mname = new JLabel("Name: ");
    private JTextField Mname = new JTextField(20);
        
    private JLabel madd = new JLabel("Address: ");
    private JTextField Madd = new JTextField(20);
        
    private JLabel memail = new JLabel("Email: ");
    private JTextField Memail = new JTextField(20);
        
    private JLabel mun = new JLabel("Username: ");
    private JTextField Mun = new JTextField(20);
        
    private JLabel mpsw = new JLabel("Password: ");
    private JTextField Mpsw = new JTextField(20);
        
    
    private JButton m2 = new JButton("Add");
   
    private JButton m4 = new JButton("Edit");
    private JButton m5 = new JButton("Previous Page");
    private JButton m6 = new JButton("Quit");

	
    private JRadioButton mr1 = new JRadioButton("Active");
    private JRadioButton mr2 = new JRadioButton("Inactive");
        
    public static DefaultTableModel za;
    public static JTable za1;
    private JPanel P1 = new JPanel();
    private String temp;



    public ManageProManager() {
	this.setTitle("Search Manager Information");
	this.setBounds(10, 10, 900, 550);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setLayout(null);
                
        int size = allProManager.size();
        String[][] data = new String[size][7];
        for (int i=0; i<size; i++){
            ProductManager PM = ImportFile.allProManager.get(i);
            data[i][0] = PM.getPMID();
            data[i][1] = PM.getsName();
            data[i][2] = PM.getAddress();
            data[i][3] = PM.getEmail();
            data[i][4] = PM.getLoginName();
            data[i][5] = PM.getPassword();
            if(PM.isStat().equals("true")){
                data[i][6] = "Active";
            }else{
                data[i][6] = "Inactive";
            }
            
        }
        String[] columnNames = {"ID","Name","Address","Email","Username","Password","Status"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        za = new DefaultTableModel (data, columnNames){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        za1 = new JTable(za);
        za1.setPreferredScrollableViewportSize(new Dimension(350, 100));
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS; 
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
        JScrollPane sp = new JScrollPane(za1,v,h);
        za1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        za1.setDefaultRenderer(Object.class, centerRenderer);
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(za1.getModel());
        za1.setRowSorter(rowSorter);
        for (int i=2; i<=za.getRowCount(); i++){
            for (int j=1; j<=za.getColumnCount(); j++){
                za.isCellEditable(i, j);
            }
        }
        P1.add(sp);
        za1.addMouseListener(this); 
        Mkw.getDocument().addDocumentListener(new DocumentListener(){
            
       
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                String text = Mkw.getText();
                
                if(text.trim().length() == 0){
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
            

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                String text = Mkw.getText();
                
                if(text.trim().length() == 0){
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

	mkw.setBounds(140, 30, 150, 20);
	this.add(mkw);
	Mkw.setBounds(270, 30, 120, 20);
	this.add(Mkw);



	m2.setBounds(100, 420, 120, 20);
	this.add(m2);
        m2.addActionListener(this);
                

                
	m4.setBounds(330, 420, 120, 20);
	this.add(m4);
        m4.addActionListener(this);

	m5.setBounds(140, 450, 120, 20);
	this.add(m5);
        m5.addActionListener(this);

	m6.setBounds(270, 450, 120, 20);
	this.add(m6);
        m6.addActionListener(this);

	maccess.setBounds(530, 400, 200, 20);
	this.add(maccess);
		
	mr1.setBounds(570, 420, 130, 20);
	mr2.setBounds(570, 450, 130, 20);
	ButtonGroup mgroup = new ButtonGroup();
	mgroup.add(mr1);
	mgroup.add(mr2);
	this.add(mr1);
	this.add(mr2);
        mr1.addActionListener(this);
        mr2.addActionListener(this);
                
        mid.setBounds(530,80,100,20);
        this.add(mid);		
        Mid.setBounds(610,80,120,20);
	this.add(Mid);
           
        mname.setBounds(530,120,100,20);
        this.add(mname);		
        Mname.setBounds(610,120,120,20);
	this.add(Mname);
           
        madd.setBounds(530,160,120,20);
        this.add(madd);		
        Madd.setBounds(610,160,120,20);
	this.add(Madd);  
             
        memail.setBounds(530,200,120,20);
        this.add(memail);	
        Memail.setBounds(610,200,120,20);
	this.add(Memail);   
        
        mun.setBounds(530,300,100,20);
        this.add(mun);		
        Mun.setBounds(610,300,120,20);
	this.add(Mun);  
           
        mpsw.setBounds(530,340,100,20);
        this.add(mpsw);		
        Mpsw.setBounds(610,340,120,20);
	this.add(Mpsw);      
           
        P1.setBounds(80,180,400,600);
        this.add(P1);

        this.setVisible(false);
    }


    @Override
    public void actionPerformed(ActionEvent ae) {


        if (ae.getSource() == m2){
            ProductCatalogueManagementSystem.page11.setVisible(true);
            ProductCatalogueManagementSystem.page5.setVisible(false);
               
        } else if (ae.getSource() == m4){
            if (Mid.getText().isEmpty()){
                JOptionPane.showMessageDialog(m4, "Please Select Manager");
            } else{
                String newAdd = Madd.getText();
                String newEmail = Memail.getText();
                String newPw = Mpsw.getText();
                try{
                    PrintWriter p1 = new PrintWriter("promanager.txt");
                    for(int i=0; i<allProManager.size(); i++){
                        ProductManager PM = allProManager.get(i);
                        if(PM.getPMID().equals(Mid.getText())){
                            p1.println(PM.getPMID());
                            p1.println(PM.getsName());
                            PM.setAddress(newAdd);
                            PM.setEmail(newEmail);
                            PM.setPassword(newPw);
                            p1.println(PM.getAddress());
                            p1.println(PM.getEmail());
                            p1.println(PM.getLoginName());
                            p1.println(PM.getPassword());
                            p1.println(PM.isStat());
                            p1.println();
                            String stat = "";
                            DefaultTableModel model = (DefaultTableModel) za1.getModel();
                            model.setValueAt(newAdd,i,2);
                            model.setValueAt(newEmail,i,3);
                            model.setValueAt(newPw,i,5);
                            if(PM.isStat().equals("true")){
                                stat = "Active";
                            }else{
                                stat = "Inactive";
                            }
                            model.setValueAt(stat,i,6);
                        } else {
                            p1.println(PM.getPMID());
                            p1.println(PM.getsName());
                            p1.println(PM.getAddress());
                            p1.println(PM.getEmail());
                            p1.println(PM.getLoginName());
                            p1.println(PM.getPassword());
                            p1.println(PM.isStat());
                            p1.println();
                        }
                    } 
                            p1.close();
                            
                }catch(Exception e){} 
                JOptionPane.showMessageDialog(m4,"Successful");
            }     
            
            int size = allProManager.size();
            String[][] data = new String[size][7];
            for (int i=0; i<size; i++){
                ProductManager PM = ImportFile.allProManager.get(i);
                data[i][0] = PM.getPMID();
                data[i][1] = PM.getsName();
                data[i][2] = PM.getAddress();
                data[i][3] = PM.getEmail();
                data[i][4] = PM.getLoginName();
                data[i][5] = PM.getPassword();
                data[i][6] = PM.isStat();
                }
            String[] columnNames = {"ID","Name","Address","Email","Username","Password","Status"};
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment( JLabel.CENTER );
            za = new DefaultTableModel (data, columnNames);
        } else if (ae.getSource() == m5){
            ProductCatalogueManagementSystem.page2.setVisible(true);
            ProductCatalogueManagementSystem.page5.setVisible(false);
        } else if (ae.getSource() == m6){
            System.exit(0);
        } else if (ae.getSource() == mr1){
            try{
                
                
                for (int i=0; i<allProManager.size(); i++){
                    ProductManager PM = allProManager.get(i);

                        PM.setStat(true);

                    
                } 
                        
            }catch (Exception e){}
            
                
        }else if (ae.getSource() == mr2){
            try{
                
                for (int i=0; i<allProManager.size(); i++){
                    ProductManager PM = allProManager.get(i);
                    if(PM.getPMID().equals(Mid.getText())){
                        PM.setStat(false);
                    }
                }
            } catch (Exception e){}
        }                     
    }    
    
    

    @Override
    public void mouseClicked(MouseEvent e) {
        int row = za1.rowAtPoint(e.getPoint());
        String temp[]= new String[6];
        for (int i=0; i<6; i++){
            za1.getValueAt(row, i);
            temp[i] = (String)za1.getValueAt(row, i);
        } 
        Mid.setText(temp[0]);
        Mid.setEditable(false);
        Mname.setText(temp[1]);
        Mname.setEditable(false);
        Madd.setText(temp[2]);
        Memail.setText(temp[3]);
        Mun.setText(temp[4]);
        Mun.setEditable(false);
        Mpsw.setText(temp[5]);
        if (za1.getValueAt(row, 6) == "Active"){
            mr1.setSelected(true);
        } else {
            mr2.setSelected(true);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
       
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public int getRowCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getColumnCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getColumnName(int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void addTableModelListener(TableModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}