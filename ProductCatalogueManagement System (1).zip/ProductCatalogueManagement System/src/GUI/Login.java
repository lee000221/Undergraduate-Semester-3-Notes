
package GUI;

import Function.ImportFile;
import ObjectClass.Administrator;
import ObjectClass.ProductManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class Login extends JFrame implements ActionListener{
	private JLabel username = new JLabel("Username:");
	private JTextField userName = new JTextField();		
	private JLabel psw = new JLabel("Password:");	
	private JPasswordField Psw = new JPasswordField(); //make password into ***
	JLabel Idt=new JLabel("Identity:");
	String str[]={"Admin","Manager"};
	JComboBox sel=new JComboBox(str);	//set selection identity
	private JButton b1, b2;
	public Login(){		
		this.setTitle("PRODUCT CATALOGUE MANAGEMENT SYSTEM");
		this.setLayout(null);// empty the layout
                b1 = new JButton("Login");
                b2 = new JButton("Quit");
		username.setBounds(160,50,100,20);//(int x, int y, int width, int height)
		this.add(username);		
		userName.setBounds(230,50,120,20);//for plain text
		this.add(userName);
		psw.setBounds(160,100,100,20);
		this.add(psw);
		Psw.setBounds(230,100,120,20);
		this.add(Psw);
		Idt.setBounds(170,150,100,20);
		this.add(Idt);
		sel.setBounds(230,150,100,20);
		this.add(sel);
		sel.addActionListener(this);
		b1.setBounds(160,210,80,20);
		this.add(b1);
		b1.addActionListener(this);
		b2.setBounds(280,210,80,20);
		this.add(b2);     
		b2.addActionListener(this);
		this.setBounds(10,10,550,330);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
                boolean found = false;
                boolean found2 = false;
		if (e.getSource() == b1) {
			String name=userName.getText();
			String password = new String(Psw.getPassword());
			if(name.length()==0&&password.length()!=0)
                            JOptionPane.showMessageDialog( null, "Please enter the username");
			else  if(name.length()!=0&&password.length()==0)
                            JOptionPane.showMessageDialog( null, "Please enter the password");
			else if(name.length()==0&&name.length()==0)
                            JOptionPane.showMessageDialog( null, "Please enter the username and passowrd");
			else if(sel.getSelectedIndex()==0&&name.length()!=0&&password.length()!=0){
                            for (int i = 0; i<ImportFile.allAdmin.size(); i++){
                                Administrator A = ImportFile.allAdmin.get(i);
                                if (name.equals(A.getLoginName())){
                                    found = true;
                                    ProductCatalogueManagementSystem.Alogin = A;
                                    break;  
                                }
                            }
                            if(found){
                                if (password.equals (ProductCatalogueManagementSystem.Alogin.getPassword())){
                                    ProductCatalogueManagementSystem.page2.setVisible(true);
                                    ProductCatalogueManagementSystem.page1.setVisible(false);
                                } else{
                                    JOptionPane.showMessageDialog(b1,"Wrong password!");
                                }
                            }else{
                                JOptionPane.showMessageDialog(b1,"Wrong username!");
                            }
                        }
                        
			else if(sel.getSelectedIndex()==1&&name.length()!=0&&password.length()!=0){
                            for (int i = 0; i<ImportFile.allProManager.size(); i++){
                                ProductManager B = ImportFile.allProManager.get(i);
                                if (name.equals(B.getLoginName())&& "true".equals(B.isStat())){
                                    found2 = true;
                                    ProductCatalogueManagementSystem.PMlogin = B;
                                    break;  
                                } else{
                                    JOptionPane.showMessageDialog(b1,"Your Account has been deactivated");
                                    break;
                                }
                            }
                            if(found2){
                                if (password.equals(ProductCatalogueManagementSystem.PMlogin.getPassword())){
                                    AddCatalogue.ac12.setText(ProductCatalogueManagementSystem.PMlogin.getsName());
                                    ProductCatalogueManagementSystem.page3.setVisible(true);
                                    ProductCatalogueManagementSystem.page1.setVisible(false);
                                } else{
                                    JOptionPane.showMessageDialog(b1,"Wrong password!");
                                }
                            }else{
                                JOptionPane.showMessageDialog(b1,"Wrong username!");
                            }
                }
                }
		else if(e.getSource()==b2)
			System.exit(0);
        
        
}
}

  

