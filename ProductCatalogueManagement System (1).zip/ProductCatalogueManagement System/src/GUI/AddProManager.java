
package GUI;

import static Function.ImportFile.allProManager;
import static Function.ImportFile.allProduct;
import ObjectClass.ProductManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class AddProManager extends JFrame implements ActionListener {
    
        private JLabel addmag = new JLabel("Please Enter the Manager Information :");
        private JLabel addmag4 = new JLabel("Please Enter the Login Information :");
        

        
        private JLabel mname = new JLabel("Name: ");
	private JTextField Mname = new JTextField(20);
        
	private JLabel madd = new JLabel("Address: ");
	private JTextField Madd = new JTextField(20);
        
        private JLabel memail = new JLabel("Email: ");
	private JTextField Memail = new JTextField(20);
        

	private JLabel mun = new JLabel("Username: ");
	private JTextField Mun = new JTextField(20);
        
	private JLabel mpsw = new JLabel("Password: ");
	private JTextField Mpsw = new JTextField(20);
        
	private JButton addmag1 = new JButton("Add");
	private JButton addmag2 = new JButton("Previous Page");
	private JButton addmag3 = new JButton("Quit");
        
        public AddProManager(){
           this.setTitle("Add Product Manager Information"); 
           this.setBounds(10,10,450,550);
           this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           this.setLayout(null);

           
           mname.setBounds(80,120,100,20);
           this.add(mname);		
           Mname.setBounds(210,120,120,20);
	   this.add(Mname);
           
           madd.setBounds(80,160,120,20);
           this.add(madd);		
           Madd.setBounds(210,160,120,20);
	   this.add(Madd);  
           
           
           memail.setBounds(80,200,120,20);
           this.add(memail);	
           Memail.setBounds(210,200,120,20);
	   this.add(Memail);   
           
 
        
           mun.setBounds(80,300,100,20);
           this.add(mun);		
           Mun.setBounds(210,300,120,20);
	   this.add(Mun);  
           
           mpsw.setBounds(80,340,100,20);
           this.add(mpsw);		
           Mpsw.setBounds(210,340,120,20);
	   this.add(Mpsw);      
           
           
           addmag.setBounds(5,10,235,80);
           this.add(addmag);
           
           addmag1.setBounds(150,420,125,20);
           this.add(addmag1);
           addmag1.addActionListener(this);  
           
           addmag2.setBounds(80,460,125,20);
           this.add(addmag2);
           addmag2.addActionListener(this);
           
           addmag3.setBounds(215,460,125,20);
           this.add(addmag3);
           addmag3.addActionListener(this);
           
           addmag4.setBounds(5,260,215,20);
           this.add(addmag4);	

           
           this.setVisible(false);
        }
        

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == addmag1){
                int number;
                int size = allProManager.size();
                if(allProManager.size() == 0){
                number = 11;
                }else{
                number = allProManager.get(size-1).getIntPMID() + 1;    
                }
                String PMid = String.valueOf(number);
                String PMname = Mname.getText();
                String PMadd = Madd.getText();
                String PMemail = Memail.getText();
                String PMun = Mun.getText();
                String PMpw = Mpsw.getText();
                ProductManager.addManager(PMid,PMname,PMadd,PMemail,PMun,PMpw);
            } else if (ae.getSource() == addmag2){
                ProductCatalogueManagementSystem.page2.setVisible(true);
                ProductCatalogueManagementSystem.page11.setVisible(false);
            } else if (ae.getSource() == addmag3){
                System.exit(0);
            }
        }


}



