
package GUI;

import static Function.ImportFile.allAdmin;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;
import ObjectClass.Administrator;
import static java.nio.file.Files.size;

public class AddAdmin extends JFrame implements ActionListener {
    
        private JLabel aa = new JLabel("Please Enter the Administrator Information :");
        private JLabel aa4 = new JLabel("Please Enter the Login Information :");
        

        
        private JLabel aname = new JLabel("Name: ");
	private JTextField Aname = new JTextField(20);
        
	private JLabel aadd = new JLabel("Address: ");
	private JTextField Aadd = new JTextField(20);
        
        private JLabel aemail = new JLabel("Email: ");
	private JTextField Aemail = new JTextField(20);
        

	private JLabel aun = new JLabel("Username: ");
	private JTextField Aun = new JTextField(20);
        
	private JLabel apsw = new JLabel("Password: ");
	private JTextField Apsw = new JTextField(20);
        
	private JButton aa1 = new JButton("Add");
	private JButton aa2 = new JButton("Previous Page");
	private JButton aa3 = new JButton("Quit");
        
        public AddAdmin(){
           this.setTitle("Add Administrator Information"); 
           this.setBounds(10,10,450,550);
           this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           this.setLayout(null);

           
           
           aname.setBounds(80,120,100,20);
           this.add(aname);		
           Aname.setBounds(210,120,120,20);
	   this.add(Aname);
           
           aadd.setBounds(80,160,120,20);
           this.add(aadd);		
           Aadd.setBounds(210,160,120,20);
	   this.add(Aadd);  
           
           
           aemail.setBounds(80,200,120,20);
           this.add(aemail);	
           Aemail.setBounds(210,200,120,20);
	   this.add(Aemail);   
           
 
        
           aun.setBounds(80,300,100,20);
           this.add(aun);		
           Aun.setBounds(210,300,120,20);
	   this.add(Aun);  
           
           apsw.setBounds(80,340,100,20);
           this.add(apsw);		
           Apsw.setBounds(210,340,120,20);
	   this.add(Apsw);      
           
           
           aa.setBounds(5,10,235,80);
           this.add(aa);
           
           aa1.setBounds(150,420,125,20);
           this.add(aa1);
           aa1.addActionListener(this);  
           
           aa2.setBounds(80,460,125,20);
           this.add(aa2);
           aa2.addActionListener(this);
           
           aa3.setBounds(215,460,125,20);
           this.add(aa3);
           aa3.addActionListener(this);
           
           aa4.setBounds(5,260,215,20);
           this.add(aa4);	

           
           this.setVisible(false);
        }
        

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == aa1){
                int number;
                int size = allAdmin.size();
                if(allAdmin.size() == 0){
                number = 1;
            }else{
                number = allAdmin.get(size - 1).getIntAID() + 1;
            }
                String Aid = Integer.toString(number);
                String Aname = this.Aname.getText();
                String Aadd = this.Aadd.getText();
                String Aemail = this.Aemail.getText();
                String Aun = this.Aun.getText();
                String Apw = this.Apsw.getText();
                Administrator.addAdmin(Aid, Aname, Aadd, Aemail, Aun, Apw);
                
                
            } else if (ae.getSource() == aa2){
                ProductCatalogueManagementSystem.page2.setVisible(true);
                ProductCatalogueManagementSystem.page13.setVisible(false);
            } else if (ae.getSource() == aa3){
                System.exit(0);
            }
        }
}


