
package GUI;

import Function.ImportFile;
import static Function.ImportFile.allCatalogue;
import static Function.ImportFile.allProManager;
import ObjectClass.Catalogue;
import ObjectClass.ProductManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;


public class AddCatalogue extends JFrame implements ActionListener {
    
        private JLabel ac = new JLabel("Please Enter the Catalogue Information :");
        
        
        private JLabel ac3 = new JLabel("Title: ");
	private JTextField ac4 = new JTextField(20);
        
	private JLabel ac5 = new JLabel("Description: ");
	private JTextField ac6 = new JTextField(20);
        
        private JLabel ac7 = new JLabel("Date from: ");
	private JTextField ac8 = new JTextField(20);
        
        private JLabel ac9 = new JLabel("To: ");
        private JTextField ac10 = new JTextField(20);
        
        private JLabel ac11 = new JLabel("Creator: ");
        public static JTextField ac12 = new JTextField(20);
        
        private JLabel ac13 = new JLabel("Time Created");
        public static JTextField ac14 = new JTextField(20);

	private JButton ac15 = new JButton("Add");
        
	private JButton ac16 = new JButton("Previous Page");
	private JButton ac17 = new JButton("Quit");
        
        public AddCatalogue(){
           this.setTitle("Add Administrator Information"); 
           this.setBounds(10,10,600,650);
           this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           this.setLayout(null);
           

           
           ac3.setBounds(130,120,100,20);
           this.add(ac3);		
           ac4.setBounds(280,120,120,20);
	   this.add(ac4);
           
           ac5.setBounds(130,160,120,20);
           this.add(ac5);		
           ac6.setBounds(280,160,120,20);
	   this.add(ac6);  
           
           
           ac7.setBounds(130,200,120,20);
           this.add(ac7);	
           ac8.setBounds(280,200,120,20);
	   this.add(ac8);   
           
           ac9.setBounds(130,240,120,20);
           this.add(ac9);
           ac10.setBounds(280,240,120,20);
           this.add(ac10);
           
           ac11.setBounds(130,280,120,20);
           this.add(ac11);
           ac12.setBounds(280,280,120,20);
           this.add(ac12);
           ac12.setEditable(false);

           ac13.setBounds(130,320,120,20);
           this.add(ac13);
           ac14.setBounds(280,320,120,20);
           this.add(ac14);
           ac14.setEditable(false);
           
           ac.setBounds(5,10,235,80);
           this.add(ac);
           
           ac15.setBounds(140,520,125,20);
           this.add(ac15);
           ac15.addActionListener(this);  
           
           
           ac16.setBounds(140,560,125,20);
           this.add(ac16);
           ac16.addActionListener(this);
           
           ac17.setBounds(265,560,125,20);
           this.add(ac17);
           ac17.addActionListener(this);

           this.setVisible(false);
        }

        
        @Override
        public void actionPerformed(ActionEvent ae) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy");
            if(ae.getSource() == ac15){
                                int number;
                int size = allCatalogue.size();
                if(allCatalogue.size() == 0){
                number = 101;
                }else{
                number = allCatalogue.get(size - 1).getReferenceNum() + 1;
                }
                Date SDate = null;
                Date EDate = null;
                String CID = String.valueOf(number);
                String Cti = ac4.getText();
                String CDes = ac6.getText();
                String CSD = ac8.getText();
                try {
                    SDate = dateFormat.parse(CSD);
                } catch (ParseException e){
                    JOptionPane.showMessageDialog(null, "Invalid format(Start Date)");
                };
                String CED = ac10.getText();
                try {
                    EDate = dateFormat.parse(CED);
                } catch (ParseException e){
                    JOptionPane.showMessageDialog(null, "Invalid format(End Date)");
                };                
                String CrName = ac12.getText();
                ProductManager creator = null;
                for (int i=0; i<allProManager.size(); i++){
                    ProductManager PM = allProManager.get(i);
                    if (CrName.equals(PM.getsName())){
                        creator = PM;
                        break;
                    }
                }
                String CrTime = ac14.getText();
                
            Catalogue newCa = new Catalogue(Integer.parseInt(CID), Cti, CDes, SDate, EDate, creator, CrTime);
                if (SDate != null && EDate != null){
                    creator.createCat(newCa);
                        ImportFile.allCatalogue.add(newCa);
                        try {
                            PrintWriter p = new PrintWriter("catalogue.txt");
                            for (int i=0 ; i< ImportFile.allCatalogue.size(); i++){
                                Catalogue CA =  ImportFile.allCatalogue.get(i);
                                p.println(CA.getReferenceNum());
                                p.println(CA.getTitle());
                                p.println(CA.getDescription());
                                String dt = dateFormat.format(CA.getStartdate());
                                p.println(dt);
                                String dt2 = dateFormat.format(CA.getEnddate());
                                p.println(dt2);
                                p.println(CA.getCreator().getsName());
                                p.println(CA.getCreateTime());
                                p.println();
                            }
                            p.close();
                            JOptionPane.showMessageDialog(null,"Successful");
                            DefaultTableModel model= (DefaultTableModel)ManageCatalogue.zd1.getModel();
                            model.addRow(new Object[]{newCa.getReferenceNum(),newCa.getTitle(),newCa.getDescription(),newCa.getStartdate(),newCa.getEnddate(),newCa.getCreator().getsName(),newCa.getCreateTime()});
                            ProductCatalogueManagementSystem.page3.setVisible(true);
                            ProductCatalogueManagementSystem.page14.setVisible(false);
                        } catch (Exception e){
                            e.getStackTrace();
                        }
                } else{
                    JOptionPane.showMessageDialog(null, "Please enter again");
                }
            } else if (ae.getSource() == ac16){
                ProductCatalogueManagementSystem.page8.setVisible(true);
                ProductCatalogueManagementSystem.page14.setVisible(false);
            } else if (ae.getSource() == ac17){
                System.exit(0);
            }
        }


}