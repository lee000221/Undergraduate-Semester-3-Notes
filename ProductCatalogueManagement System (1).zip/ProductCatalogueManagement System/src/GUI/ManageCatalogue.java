
package GUI;

import Function.CatalogueItem;
import Function.ImportFile;
import static Function.ImportFile.allCatItem;
import static Function.ImportFile.allCatalogue;
import static Function.ImportFile.allProduct;
import ObjectClass.Catalogue;
import static ObjectClass.Catalogue.getMyProduct;
import ObjectClass.ProductItem;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.DocumentListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class ManageCatalogue extends JFrame implements ActionListener, MouseListener, TableModel{
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy");
    public static String createtime;

    private JTextField Sckw = new JTextField();
    
    private JLabel sc1 = new JLabel("Reference Number: ");
    public static JTextField sc2 = new JTextField(20);
        
    private JLabel sc3 = new JLabel("Title: ");
    private JTextField sc4 = new JTextField(20);
        
    private JLabel sc5 = new JLabel("Description: ");
    private JTextField sc6 = new JTextField(20);
        
    private JLabel sc7 = new JLabel("Date from: ");
    private JTextField sc8 = new JTextField(20);
        
    private JLabel sc9 = new JLabel("To: ");
    private JTextField sc10 = new JTextField(20);
        
    private JLabel sc11 = new JLabel("Creator: ");
    public static JTextField sc12 = new JTextField(20);
        
    private JLabel sc13 = new JLabel("Time Created");
    public static JTextField sc14 = new JTextField(20);
    
    private JButton sc15 = new JButton("Add");
    private JButton sc16 = new JButton("Delete");
    private JButton sc17 = new JButton("Edit");
    private JButton sc18 = new JButton("Previous Page");
    private JButton sc19 = new JButton("Quit");
    private JButton sc20 = new JButton("Manage Catalogue Item");
   
    public static DefaultTableModel zd;
    public static JTable zd1;
    private JPanel P1 = new JPanel();
    private String temp;


    
    public ManageCatalogue() {
        this.setTitle("Search Catalogue Information"); 
        this.setBounds(10,10,900,550);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        
        int size = allCatalogue.size();
        String[][] data = new String[size][7];
        for (int i=0; i<size; i++){
        Catalogue CA = ImportFile.allCatalogue.get(i);
        data[i][0] = Integer.toString(CA.getReferenceNum());
        data[i][1] = CA.getTitle();
        data[i][2] = CA.getDescription();
        data[i][3] = dateFormat.format(CA.getStartdate());
        data[i][4] = dateFormat.format(CA.getEnddate());
        data[i][5] = CA.getCreator().getsName();
        data[i][6] = CA.getCreateTime();
        }
        String[] columnNames = {"Reference No.","Title","Description","Start Date","End Date","Creator", "Time Created"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        zd = new DefaultTableModel (data, columnNames){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        zd1 = new JTable(zd);
        zd1.setPreferredScrollableViewportSize(new Dimension(350, 100));
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS; 
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
        JScrollPane sp = new JScrollPane(zd1,v,h);
        zd1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        zd1.setDefaultRenderer(Object.class, centerRenderer);
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(zd1.getModel());
        zd1.setRowSorter(rowSorter);
        for (int i=2; i<=zd.getRowCount(); i++){
            for (int j=1; j<=zd.getColumnCount(); j++){
                zd.isCellEditable(i, j);
            }
        }
        P1.add(sp);
        zd1.addMouseListener(this); 
        
        
        Sckw.getDocument().addDocumentListener(new DocumentListener(){
            
       
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                String text = Sckw.getText();
                
                if(text.trim().length() == 0){
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
            

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                String text = Sckw.getText();
                
                if(text.trim().length() == 0){
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        
 
           sc1.setBounds(530,80,100,20);
           this.add(sc1);		
           sc2.setBounds(610,80,120,20);
	   this.add(sc2);
           
           sc3.setBounds(530,120,100,20);
           this.add(sc3);		
           sc4.setBounds(610,120,120,20);
	   this.add(sc4);
           
           sc5.setBounds(530,160,120,20);
           this.add(sc5);		
           sc6.setBounds(610,160,120,20);
	   this.add(sc6);  
           
           
           sc7.setBounds(530,200,120,20);
           this.add(sc7);	
           sc8.setBounds(610,200,120,20);
	   this.add(sc8);   
           
           sc9.setBounds(530,240,100,20);
           this.add(sc9);		
           sc10.setBounds(610,240,120,20);
	   this.add(sc10);  
           
           sc11.setBounds(530,280,100,20);
           this.add(sc11);		
           sc12.setBounds(610,280,120,20);
	   this.add(sc12);  
           
           sc13.setBounds(530,320,100,20);
           this.add(sc13);		
           sc14.setBounds(610,320,120,20);
	   this.add(sc14);      
        
		
           Sckw.setBounds(280,30,120,20);
	   this.add(Sckw);
           
           sc15.setBounds(205,70,120,20);
           this.add(sc15);
           sc15.addActionListener(this);
           
           sc16.setBounds(100,420,120,20);
	   this.add(sc16); 
           sc16.addActionListener(this);
           
           sc17.setBounds(215,420,120,20);
           this.add(sc17);
           sc17.addActionListener(this);
           
           sc18.setBounds(335,420,120,20);
	   this.add(sc18);   
           sc18.addActionListener(this);
           
 
           sc19.setBounds(140,450,120,20);
           this.add(sc19);
           sc19.addActionListener(this);

           sc20.setBounds(530,360,120,20);
           this.add(sc20);
           sc20.addActionListener(this);
           
           P1.setBounds(80,180,400,600);
           this.add(P1);
           
           this.setVisible(false);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == sc15){
            createtime = Calendar.getInstance().getTime().toString();
            AddCatalogue.ac14.setText(createtime);
            ProductCatalogueManagementSystem.page14.setVisible(true);
            ProductCatalogueManagementSystem.page8.setVisible(false);
        } else if (ae.getSource() == sc16){
            try{
                PrintWriter p1 = new PrintWriter("catalogue.txt");
                for(int i=0; i<allCatalogue.size(); i++){
                    Catalogue CA = allCatalogue.get(i);
                    if(sc2.getText().equals(CA.getReferenceNum())){
                        DefaultTableModel model = (DefaultTableModel) zd1.getModel();
                        model.removeRow(i);
                    } else {
                        p1.println(CA.getReferenceNum());
                        p1.println(CA.getTitle());
                        p1.println(CA.getDescription());
                        String dt = dateFormat.format(CA.getStartdate());
                        p1.println(dt);
                        String dt2 = dateFormat.format(CA.getEnddate());
                        p1.println(dt2);
                        p1.println(CA.getCreator().getsName());
                        p1.println(CA.getCreateTime());
                        p1.println();
                    }
                } 
                        p1.close();
                    }catch(Exception e){}                  
        } else if (ae.getSource() == sc17){
            
            Date newSDate = null;
            Date newEDate = null;
            String newDes = sc6.getText();
            String newStart = sc8.getText();
            try {
                newSDate = dateFormat.parse(newStart);
            } catch (ParseException e){
                JOptionPane.showMessageDialog(null, "Invalid format(Start Date)");
            };
            String newEnd = sc10.getText();
            try {
                newEDate = dateFormat.parse(newEnd);
            } catch (ParseException e){
                JOptionPane.showMessageDialog(null, "Invalid format(End Date)");
            };
            
            if (newSDate != null && newEDate != null){
                try{
                    PrintWriter p1 = new PrintWriter("catalogue.txt");
                    for(int i=0; i<allCatalogue.size(); i++){
                        Catalogue CA = allCatalogue.get(i);
                        if(sc2.getText().equals(CA.getReferenceNum())){
                            p1.println(CA.getReferenceNum());
                            p1.println(CA.getTitle());
                            CA.setDescription(newDes);
                            CA.setStartdate(newSDate);
                            CA.setEnddate(newEDate);
                            p1.println(CA.getDescription());
                            String dt = dateFormat.format(CA.getStartdate());
                            p1.println(dt);
                            String dt2 = dateFormat.format(CA.getEnddate());
                            p1.println(dt2);
                            p1.println(CA.getCreator());
                            p1.println(CA.getCreateTime());
                            p1.println();
                            DefaultTableModel model = (DefaultTableModel) zd1.getModel();
                            model.setValueAt(newDes,i,2);
                            model.setValueAt(newStart,i,3);
                            model.setValueAt(newEnd,i,4);

                        } else {
                            p1.println(CA.getReferenceNum());
                            p1.println(CA.getTitle());
                            p1.println(CA.getDescription());
                            p1.println(CA.getDescription());
                            String dt = dateFormat.format(CA.getStartdate());
                            p1.println(dt);
                            String dt2 = dateFormat.format(CA.getEnddate());
                            p1.println(dt2);
                            p1.println(CA.getCreator());
                            p1.println(CA.getCreateTime());
                            p1.println();
                        }
                    } 
                            p1.close();
                        }catch(Exception e){}      
                        JOptionPane.showMessageDialog(sc17,"Successful");
            }else {
                JOptionPane.showMessageDialog(null, "Please enter again");
            }
                        int size = allCatalogue.size();
                        String[][] data = new String[size][7];
                        for (int i=0; i<size; i++){
                            Catalogue CA = ImportFile.allCatalogue.get(i);
                            data[i][0] = Integer.toString(CA.getReferenceNum());
                            data[i][1] = CA.getTitle();
                            data[i][2] = CA.getDescription();
                            data[i][3] = dateFormat.format(CA.getStartdate());
                            data[i][4] = dateFormat.format(CA.getEnddate());
                            data[i][5] = CA.getCreator().getsName();
                            data[i][5] = CA.getCreateTime();
                            }
        String[] columnNames = {"Reference No.","Title","Description","Start Date","End Date","Creator", "Time Created"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        zd = new DefaultTableModel (data, columnNames);
        } else if (ae.getSource() == sc18){
            ProductCatalogueManagementSystem.page3.setVisible(true);
            ProductCatalogueManagementSystem.page8.setVisible(false);
        } else if (ae.getSource() == sc19){
            System.exit(0);
        } else if (ae.getSource() == sc20){
            if(sc2.getText().isEmpty()){
                JOptionPane.showMessageDialog(sc20, "Please Select Catalogue");
            } else {
                ManageCatItem.getA().setText(sc2.getText());
                Catalogue CT = new Catalogue();
                for (int i=0; i<allCatalogue.size(); i++){
                    Catalogue temp = allCatalogue.get(i);
                    if (sc2.getText() == String.valueOf(temp.getReferenceNum())){
                        CT = temp;
                    }
                }
                
                Catalogue C = null;
                ProductItem P = null;
                for (int i=0; i<allCatItem.size(); i++){
                    CatalogueItem CI = allCatItem.get(i);
                    C = new Catalogue();
                    P = new ProductItem();
                    for (int j=0; j<allCatalogue.size(); j++){
                        Catalogue tempc = allCatalogue.get(i);
                        if (CI.getCatalagueReference() == tempc.getReferenceNum()){
                            C = tempc; 
                            for (int k=0; k<allProduct.size(); k++){
                                ProductItem tempp = allProduct.get(k);
                                if (CI.getProductID() == tempp.getPID()){
                                    P = tempp;
                                    break;
                                }
                            }
                        }
                    }
                }
                C.getMyProduct().add(P);  
                DefaultTableModel model= (DefaultTableModel)ManageCatItem.zc3.getModel();
                for (int i=0; i<CT.getMyProduct().size(); i++){
                    ProductItem newP = CT.getMyProduct().get(i);
                    model.addRow(new Object[]{newP.getPID(),newP.getpName(),newP.getPrice()});
                }
                ProductCatalogueManagementSystem.page15.setVisible(true);
                ProductCatalogueManagementSystem.page8.setVisible(false);
                System.out.println(CT.getMyProduct());
                System.out.println(allProduct);
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {                                          
        int row = zd1.rowAtPoint(e.getPoint());
        String temp[]= new String[7];
        for (int i=0; i<7; i++){
            zd1.getValueAt(row, i);
            temp[i] = (String)zd1.getValueAt(row, i);
            } 
        sc2.setText(temp[0]);
        sc2.setEditable(false);
        sc4.setText(temp[1]);
        sc4.setEditable(false);
        sc6.setText(temp[2]);
        sc8.setText(temp[3]);
        sc10.setText(temp[4]);
        sc12.setText(temp[5]);
        sc12.setEditable(false);
        sc14.setText(temp[6]);
        sc14.setEditable(false);
    }
    
    @Override
    public void mousePressed(MouseEvent e2) {}

    @Override
    public void mouseReleased(MouseEvent e3) {}
        
    @Override
    public void mouseEntered(MouseEvent e4) {}
        
    @Override
    public void mouseExited(MouseEvent e5) {}

    @Override
    public int getRowCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getColumnCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getColumnName(int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void addTableModelListener(TableModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    
    
 
}
