
package GUI;

import Function.ImportFile;
import static Function.ImportFile.allProManager;
import static Function.ImportFile.allSupplier;
import static GUI.ManageProManager.za;
import static GUI.ManageProManager.za1;
import ObjectClass.ProductManager;
import ObjectClass.Supplier;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.PrintWriter;
import static java.util.Calendar.PM;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.DocumentListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class ManageSupplier extends JFrame implements ActionListener, MouseListener, TableModel{

    private JLabel skw = new JLabel("Enter the Manager ID :");
    private JTextField Skw = new JTextField();	
    
    private JLabel saccess = new JLabel("Product Supplier Status : ");
   
    private JLabel sid = new JLabel("ID: ");
    private JTextField Sid = new JTextField(20);
        
    private JLabel sname = new JLabel("Name: ");
    private JTextField Sname = new JTextField(20);
        
    private JLabel sadd = new JLabel("Address: ");
    private JTextField Sadd = new JTextField(20);
    
  
    private JButton ss2 = new JButton("Add");

    private JButton ss4 = new JButton("Edit");
    private JButton ss5 = new JButton("Previous Page");
    private JButton ss6 = new JButton("Quit");

    
    private JRadioButton sr1 = new JRadioButton("Active");
    private JRadioButton sr2 = new JRadioButton("Inactive");

    public static DefaultTableModel zb;
    public static JTable zb1;
    private JPanel P1 = new JPanel();
    private String temp;    
    
    public ManageSupplier() {
        this.setTitle("Search Supplier Information"); 
        this.setBounds(10,10,700,550);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        
        int size = allSupplier.size();
        String[][] data = new String[size][4];
        for (int i=0; i<size; i++){
            Supplier SU = ImportFile.allSupplier.get(i);
            data[i][0] = SU.getSuID();
            data[i][1] = SU.getSuName();
            data[i][2] = SU.getSuAdd();
            data[i][3] = SU.isStat();
            if(SU.isStat().equals("true")){
                data[i][3] = "Active";
            }else{
                data[i][3] = "Inactive";
            }
            
        }
        String[] columnNames = {"ID","Name","Address","Status"};
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment( JLabel.CENTER );
        zb = new DefaultTableModel (data, columnNames){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        zb1 = new JTable(zb);
        zb1.setPreferredScrollableViewportSize(new Dimension(350, 100));
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS; 
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
        JScrollPane sp = new JScrollPane(zb1,v,h);
        zb1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        zb1.setDefaultRenderer(Object.class, centerRenderer);
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(zb1.getModel());
        zb1.setRowSorter(rowSorter);
        for (int i=2; i<=zb.getRowCount(); i++){
            for (int j=1; j<=zb.getColumnCount(); j++){
                zb.isCellEditable(i, j);
            }
        }
        P1.add(sp);
        zb1.addMouseListener(this); 
        Skw.getDocument().addDocumentListener(new DocumentListener(){
            
       
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                String text = Skw.getText();
                
                if(text.trim().length() == 0){
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
            

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                String text = Skw.getText();
                
                if(text.trim().length() == 0){
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });        

           skw.setBounds(80,30,150,20);
           this.add(skw);		
           Skw.setBounds(210,30,120,20);
	   this.add(Skw);
           

           
           ss2.setBounds(40,420,120,20);
	   this.add(ss2);  
           ss2.addActionListener(this);
           

           ss4.setBounds(280,420,120,20);
	   this.add(ss4);  
           ss4.addActionListener(this);
 
           ss5.setBounds(80,450,120,20);
           this.add(ss5);
           ss5.addActionListener(this);
           
           ss6.setBounds(210,450,120,20);
	   this.add(ss6);  
           ss6.addActionListener(this);
                     
           saccess.setBounds(520, 240, 200, 20);
           this.add(saccess);
           
           sid.setBounds(530,80,100,20);
           this.add(sid);		
           Sid.setBounds(610,80,120,20);
	   this.add(Sid);
           
           sname.setBounds(530,120,100,20);
           this.add(sname);		
           Sname.setBounds(610,120,120,20);
	   this.add(Sname);
           
           sadd.setBounds(530,160,100,20);
           this.add(sadd);		
           Sadd.setBounds(610,160,120,20);
	   this.add(Sadd);
		
           sr1.setBounds(550, 270, 130, 20);
           sr2.setBounds(550, 300, 130, 20);
           ButtonGroup sgroup = new ButtonGroup();
           sgroup.add(sr1);
           sgroup.add(sr2);
           this.add(sr1);
           this.add(sr2); 
           sr1.addActionListener(this);
           sr2.addActionListener(this);
           
           P1.setBounds(80,180,400,600);
           this.add(P1);
           
           this.setVisible(false);
    }

    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == ss2){
            ProductCatalogueManagementSystem.page12.setVisible(true);
            ProductCatalogueManagementSystem.page6.setVisible(false);
               
        } else if (ae.getSource() == ss4){
            if (Sid.getText().isEmpty()){
                JOptionPane.showMessageDialog(ss4, "Please Select Supplier");
            } else{
                String newAdd = Sadd.getText();
                try{
                    PrintWriter p1 = new PrintWriter("supplier.txt");
                    for(int i=0; i<allSupplier.size(); i++){
                        Supplier SU = allSupplier.get(i);
                        if(SU.getSuID().equals(Sid.getText())){
                            p1.println(SU.getSuID());
                            p1.println(SU.getSuName());
                            SU.setSuAdd(newAdd);
                            p1.println(SU.getSuAdd());
                            p1.println(SU.isStat());
                            p1.println();
                            String stat="";
                            DefaultTableModel model = (DefaultTableModel) zb1.getModel();
                            model.setValueAt(newAdd,i,2);
                            if(SU.isStat().equals("true")){
                                stat = "Active";
                            }else{
                                stat = "Inactive";
                            }
                            model.setValueAt(stat,i,3);

                        } else {
                            p1.println(SU.getSuID());
                            p1.println(SU.getSuName());
                            p1.println(SU.getSuAdd());
                            p1.println(SU.isStat());
                            p1.println();
                        }
                    } 
                            p1.close();
                }catch(Exception e){}   
                JOptionPane.showMessageDialog(ss4,"Successful");
            }   
            
            int size = allSupplier.size();
            String[][] data = new String[size][4];
            for (int i=0; i<size; i++){
                Supplier SU = ImportFile.allSupplier.get(i);
                data[i][0] = SU.getSuID();
                data[i][1] = SU.getSuName();
                data[i][2] = SU.getSuAdd();
                data[i][3] = SU.isStat();
                
                }
            String[] columnNames = {"ID","Name","Address","Status"};
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment( JLabel.CENTER );
            zb = new DefaultTableModel (data, columnNames);
        } else if (ae.getSource() == ss5){
            ProductCatalogueManagementSystem.page2.setVisible(true);
            ProductCatalogueManagementSystem.page6.setVisible(false);
        } else if (ae.getSource() == ss6){
            System.exit(0);
        } else if (ae.getSource() == sr1){
            try{
                
                for (int i=0; i<allSupplier.size(); i++){
                    Supplier SU = allSupplier.get(i);
                    if(SU.getSuID().equals(Sid.getText())){
                        SU.setStat(true);
  
                    } 
                    
                } 
                        
            }catch (Exception e){}
            
                
        }else if (ae.getSource() == sr2){
            try{
                for (int i=0; i<allSupplier.size(); i++){
                    Supplier SU= allSupplier.get(i);
                    if(SU.getSuID().equals(Sid.getText())){
                        SU.setStat(false);

                    } 
                    
                }
            } catch (Exception e){}
        }                     
    }    

    @Override
    public void mouseClicked(MouseEvent e) {
        int row = zb1.rowAtPoint(e.getPoint());
        String temp[]= new String[6];
        for (int i=0; i<3; i++){
            zb1.getValueAt(row, i);
            temp[i] = (String)zb1.getValueAt(row, i);
        } 
        Sid.setText(temp[0]);
        Sid.setEditable(false);
        Sname.setText(temp[1]);
        Sname.setEditable(false);
        Sadd.setText(temp[2]);
        if (zb1.getValueAt(row, 3) == "Active"){
            sr1.setSelected(true);
        } else {
            sr2.setSelected(true);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    
    }

    @Override
    public void mouseReleased(MouseEvent e) {}
        

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public int getRowCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getColumnCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getColumnName(int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void addTableModelListener(TableModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

}   



