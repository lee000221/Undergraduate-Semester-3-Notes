
package GUI;

import static Function.ImportFile.allProManager;
import ObjectClass.ProductManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintWriter;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class ManagePersonalProfile extends JFrame implements ActionListener {
    
        private JLabel cg = new JLabel("You can edit your password here :");

        
        private JLabel cgu = new JLabel("Please enter your username : ");
	private JTextField Cgu = new JTextField(20);
        
        private JLabel crpsw = new JLabel("Please enter your current password : ");
	private JTextField Crpsw = new JTextField(20);
        
        private JLabel npsw = new JLabel("Please enter your new password : ");
	private JTextField Npsw = new JTextField(20);

	private JButton cg1 = new JButton("Edit");
	private JButton cg2 = new JButton("Previous Page");
	private JButton cg3 = new JButton("Quit");
        
        public ManagePersonalProfile (){
           this.setTitle("Change the password information"); 
           this.setBounds(10,10,450,520);
           this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           this.setLayout(null);
           
           cgu.setBounds(120,90,200,20);	
           this.add(cgu);
           Cgu.setBounds(140,130,120,20);
	   this.add(Cgu);

           crpsw.setBounds(100,170,250,20);
           this.add(crpsw);		
           Crpsw.setBounds(140,210,120,20);
	   this.add(Crpsw);  
           
           npsw.setBounds(110,250,250,20);
           this.add(npsw);		
           Npsw.setBounds(140,290,120,20);
	   this.add(Npsw);            
 
           
           
           cg.setBounds(5,10,250,80);
           this.add(cg);
           
 
           cg1.setBounds(150,350,100,20);
           this.add(cg1);
           cg1.addActionListener(this);  
           
           cg2.setBounds(75,390,120,20);
           this.add(cg2);
           cg2.addActionListener(this);
           
           cg3.setBounds(205,390,120,20);
           this.add(cg3);
           cg3.addActionListener(this);
           
           this.setVisible(false);
        }
        

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == cg1){
                ProductManager PM = new ProductManager();
                int index = 0;
                for ( int i=0; i<allProManager.size(); i++){
                    PM = allProManager.get(i);
                    if (ProductCatalogueManagementSystem.PMlogin.getLoginName().equals(PM.getLoginName())){
                        index = i;
                        break;
                    }
                }
                String newLN = Cgu.getText();
                String oldPW = Crpsw.getText();
                String newPW = Npsw.getText();
                if (oldPW.equals(PM.getPassword())){
                    PM.setLoginName(newLN);
                    PM.setPassword(newPW);
                    try{
                        PrintWriter p1 = new PrintWriter("promanager.txt");
                        for(int i=0; i<allProManager.size(); i++){
                            ProductManager pm = allProManager.get(i);
                            if(pm.equals(PM)){
                                p1.println(pm.getPMID());
                                p1.println(pm.getsName());
                                p1.println(pm.getAddress());
                                p1.println(pm.getEmail());
                                pm.setLoginName(newLN);
                                pm.setPassword(newPW);
                                p1.println(pm.getLoginName());
                                p1.println(pm.getPassword());
                                p1.println();
                            } else {
                                p1.println(pm.getPMID());
                                p1.println(pm.getsName());
                                p1.println(pm.getAddress());
                                p1.println(pm.getEmail());
                                p1.println(pm.getLoginName());
                                p1.println(pm.getPassword());
                                p1.println();
                            }
                        } 
                        p1.close();
                    }catch(Exception e){}      
                    JOptionPane.showMessageDialog(cg1,"Successful");
                    ProductCatalogueManagementSystem.page3.setVisible(true);
                    ProductCatalogueManagementSystem.page9.setVisible(false);
                } else {
                    JOptionPane.showMessageDialog(cg1,"Incorrect Current Password");
                }

            } else if (ae.getSource() == cg2){
                ProductCatalogueManagementSystem.page3.setVisible(true);
                ProductCatalogueManagementSystem.page9.setVisible(false);
            } else if (ae.getSource() == cg3){
                System.exit(0);
            }
        }


}


