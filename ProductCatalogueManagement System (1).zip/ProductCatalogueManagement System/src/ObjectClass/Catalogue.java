
package ObjectClass;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Catalogue {
    private int referenceNum;
    private String title, description, CreateTime;
    private Date Startdate, Enddate;
    private ProductManager creator;
    private static ArrayList<ProductItem> myProduct = new ArrayList<>();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy");
    
    public Catalogue(){}

    public Catalogue(int referenceNum, String title, String description, Date Startdate, Date Enddate, ProductManager creator, String CreateTime) {
        this.referenceNum = referenceNum;
        this.title = title;
        this.description = description;
        this.Startdate = Startdate;
        this.Enddate = Enddate;
        this.creator = creator;
        this.CreateTime = CreateTime;
        myProduct = new ArrayList<ProductItem>();
 
    }

    public static ArrayList<ProductItem> getMyProduct() {
        return myProduct;
    }


    

    public int getReferenceNum() {
        return referenceNum;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreateTime() {
        return CreateTime;
    }

    public Date getStartdate() {
        return Startdate;
    }

    public void setStartdate(Date Startdate) {
        this.Startdate = Startdate;
    }

    public Date getEnddate() {
        return Enddate;
    }

    public void setEnddate(Date Enddate) {
        this.Enddate = Enddate;
    }


    public ProductManager getCreator() {
        return creator;
    }

    public void setCreator(ProductManager creator) {
        this.creator = creator;
    }
    
    
    
//    public ProductManager findPM(){
//        
//    }
//    
    
}
