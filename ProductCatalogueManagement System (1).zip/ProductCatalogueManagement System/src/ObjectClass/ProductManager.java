
package ObjectClass;

import Function.ImportFile;
import GUI.ManageProManager;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class ProductManager extends Staff {
    private int PMID;
    private boolean Stat =true;
    public static ArrayList<Catalogue> myCatalogue;
    public ProductManager(int PMID, String sName, String address, String email, String loginName, String password, boolean Stat){
        super(sName, address, email, loginName, password);
        this.PMID = PMID;
        this.Stat=Stat;
        myCatalogue = new ArrayList<Catalogue>();
    }
    
    public void createCat(Catalogue C){
        myCatalogue.add(C);
    }

    public ArrayList<Catalogue> getMyCatalogue() {
        return myCatalogue;
    }

    public void setMyCatalogue(ArrayList<Catalogue> myCatalogue) {
        this.myCatalogue = myCatalogue;
    }
    
    public ProductManager(int PMID, String sName, String address, String email, String loginName, String password){
        this(PMID, sName,address,email,loginName, password, true);
    }
    
    public ProductManager(){
        this(0,"","","","","",true);
    }
    
    public int getIntPMID(){
        return PMID;
    }
     
    public String getPMID() {
        return Integer.toString(PMID);
    }

    public String isStat() {
        return Boolean.toString(Stat);
    }

    public void setStat(boolean Stat) {
        this.Stat = Stat;
    }
    
    public static void addManager(String PMID, String sName, String address, String email, String loginName, String password){
                ProductManager newPM = new ProductManager(Integer.parseInt(PMID), sName, address, email, loginName, password, true);
                ImportFile.allProManager.add(newPM);
                try {
                    PrintWriter p = new PrintWriter("promanager.txt");
                    for (int i=0 ; i< ImportFile.allProManager.size(); i++){
                        ProductManager PM =  ImportFile.allProManager.get(i);
                        p.println(PM.getPMID());
                        p.println(PM.getsName());
                        p.println(PM.getAddress());
                        p.println(PM.getEmail());
                        p.println(PM.getLoginName());
                        p.println(PM.getPassword());
                        p.println(PM.isStat());
                        p.println();
                    }
                    p.close();
                    JOptionPane.showMessageDialog(null,"Successful");
                    DefaultTableModel model= (DefaultTableModel)ManageProManager.za1.getModel();
                    String stat;
                    if(newPM.isStat().equals("true")){
                        stat = "Active";
                    }else{
                        stat = "Inactive";
                    }
                    model.addRow(new Object[]{newPM.getPMID(),newPM.getsName(),newPM.getAddress(),newPM.getEmail(),newPM.getLoginName(),newPM.getPassword(),stat});
                    ProductCatalogueManagementSystem.page2.setVisible(true);
                    ProductCatalogueManagementSystem.page11.setVisible(false);
                } catch (Exception e){
                    e.getStackTrace();
                }

    }
}
