
package ObjectClass;

import Function.ImportFile;
import GUI.AddProduct;
import GUI.ManageSupplier;
import java.io.PrintWriter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class Supplier {
    private int suID;
    private String suName;
    private String suAdd;
    private boolean Stat;
    public Supplier(int suID, String suName, String suAdd, boolean Stat){
        this.suID = suID;
        this.suName = suName;
        this.suAdd = suAdd;
        this.Stat = Stat;
    }
    
    public Supplier(int suID, String suAdd, String suName){
        this(suID, suName, suAdd, false);
    }

    public String isStat() {
        return Boolean.toString(Stat);
    }

    public void setStat(boolean Stat) {
        this.Stat = Stat;
    }

    public int getIntSuID(){
        return suID;
    }
    
    public String getSuID() {
        return Integer.toString(suID);
    }

    public String getSuName() {
        return suName;
    }

    public void setSuAdd(String suAdd) {
        this.suAdd = suAdd;
    }

    public String getSuAdd() {
        return suAdd;
    }
    
    public static void addSupplier(String suID, String suName, String suAdd){
        Supplier newSU = new Supplier(Integer.parseInt(suID), suName, suAdd, true);
                ImportFile.allSupplier.add(newSU);
                try {
                    PrintWriter p = new PrintWriter("supplier.txt");
                    for (int i=0 ; i< ImportFile.allSupplier.size(); i++){
                        Supplier SU =  ImportFile.allSupplier.get(i);
                        p.println(SU.getSuID());
                        p.println(SU.getSuName());
                        p.println(SU.getSuAdd());
                        p.println(SU.isStat());
                        p.println();
                    }
                    p.close();
                    String[] SUchoice = AddProduct.SupChoices();
                    JOptionPane.showMessageDialog(null,"Successful");
                    DefaultTableModel model= (DefaultTableModel)ManageSupplier.zb1.getModel();
                    String stat;
                    if(newSU.isStat().equals("true")){
                        stat = "Active";
                    }else{
                        stat = "Inactive";
                    }
                    model.addRow(new Object[]{newSU.getSuID(),newSU.getSuName(),newSU.getSuAdd(),stat});
                    ProductCatalogueManagementSystem.page6.setVisible(true);
                    ProductCatalogueManagementSystem.page12.setVisible(false);
                    
                } catch (Exception e){
                    e.getStackTrace();
                }
    }
}
