
package ObjectClass;

import Function.ImportFile;
import GUI.ManageAdmin;

import java.io.PrintWriter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class Administrator extends Staff {
    private int AID;
    public Administrator(int AID, String sName, String address, String email, String loginName, String password){
        super(sName, address, email, loginName, password);
        //this.AID = calSID();
        this.AID = AID;
    }
    
    public Administrator(int AID, String sName, String address, String email){
        this(AID, sName,address,email,"admin","admin");
        //this.AID = calSID();
    }
    
    public int getIntAID(){
        return AID;
    } 
    
    public String getAID() {
        return Integer.toString(AID);
    }
    
    public static void addAdmin(String AID, String sName, String address, String email, String loginName, String password){
        Administrator newA = new Administrator(Integer.parseInt(AID), sName, address, email, loginName, password);
                ImportFile.allAdmin.add(newA);
                try {
                    PrintWriter p = new PrintWriter("admin.txt");
                    for (int i=0 ; i< ImportFile.allAdmin.size(); i++){
                        Administrator A =  ImportFile.allAdmin.get(i);
                        p.println(A.getAID());
                        p.println(A.getsName());
                        p.println(A.getAddress());
                        p.println(A.getEmail());
                        p.println(A.getLoginName());
                        p.println(A.getPassword());
                        p.println();
                    }
                    p.close();
                    JOptionPane.showMessageDialog(null,"Successful");
                    DefaultTableModel model= (DefaultTableModel)ManageAdmin.z1.getModel();
                    model.addRow(new Object[]{newA.getAID(),newA.getsName(),newA.getAddress(),newA.getEmail(),newA.getLoginName(),newA.getPassword()});
                    ProductCatalogueManagementSystem.page14.setVisible(true);
                    ProductCatalogueManagementSystem.page13.setVisible(false);
                } catch (Exception e){
                    e.getStackTrace();
                }
    }

}
