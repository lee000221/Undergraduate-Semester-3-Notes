
package ObjectClass;

import Function.ImportFile;
import GUI.ManageProduct;
import java.io.PrintWriter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import productcataloguemanagement.system.ProductCatalogueManagementSystem;

public class ProductItem {
    private int PID;
    private String pName, description, category, supplier;
    private double price;
    private Catalogue catalogue;
    
    public ProductItem(){}

    public ProductItem(int PID, String pName, double price, String description, String category, String supplier){
        this.PID = PID;
        this.pName = pName;
        this.price = price;
        this.description = description;
        this.category = category;
        this.supplier = supplier;
//        this.catalogue = catalogue;

    }


    
    
//    public String calPID(){
//        return "HELLO";
//    }

    public int getPID() {
        return PID;
    }

    public String getCategory() {
        return category;
    }

    public String getSupplier() {
        return supplier;
    }

    public String getpName() {
        return pName;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }

    public void setSupplier(String supplierID) {
        this.supplier = supplier;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    public static void addProduct(String PID, String pName, String price, String description, String category, String supplier){
                ProductItem newP = new ProductItem(Integer.parseInt(PID), pName, Double.parseDouble(price), description, category, supplier);
                ImportFile.allProduct.add(newP);
                try {
                    PrintWriter p = new PrintWriter("product.txt");
                    for (int i=0 ; i< ImportFile.allProduct.size(); i++){
                        ProductItem P =  ImportFile.allProduct.get(i);
                        p.println(P.getPID());
                        p.println(P.getpName());
                        p.println(P.getPrice());
                        p.println(P.getDescription());
                        p.println(P.getCategory());
                        p.println(P.getSupplier());
      
                        p.println();
                    }
                    p.close();
                    JOptionPane.showMessageDialog(null,"Successful");
                    DefaultTableModel model= (DefaultTableModel)ManageProduct.zc1.getModel();
                    model.addRow(new Object[]{newP.getPID(),newP.getpName(),newP.getPrice(),newP.getDescription(),newP.getCategory(),newP.getSupplier()});
                    ProductCatalogueManagementSystem.page2.setVisible(true);
                    ProductCatalogueManagementSystem.page10.setVisible(false);
                } catch (Exception e){
                    e.getStackTrace();
                }
    }
    
}
