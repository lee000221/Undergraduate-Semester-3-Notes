
package productcataloguemanagement.system;

import Function.ImportFile;
import GUI.AddAdmin;
import GUI.AddCatalogue;
import GUI.AddProManager;
import GUI.AddProSupplier;
import GUI.AddProduct;
import GUI.DashboardAdmin;
import GUI.DashboardManager;
import GUI.Login;
import GUI.ManageAdmin;
import GUI.ManageCatItem;
import GUI.ManageCatalogue;
import GUI.ManagePersonalProfile;
import GUI.ManageProManager;
import GUI.ManageProduct;
import GUI.ManageSupplier;
import ObjectClass.Administrator;
import ObjectClass.ProductManager;


public class ProductCatalogueManagementSystem {
    public static Administrator Alogin;
    public static ProductManager PMlogin;
    public static Login page1;
    public static DashboardAdmin page2;
    public static DashboardManager page3;
    public static ManageProduct page4;
    public static ManageProManager page5;
    public static ManageSupplier page6;
    public static ManageAdmin page7;
    public static ManageCatalogue page8;
    public static ManagePersonalProfile page9;
    public static AddProduct page10;
    public static AddProManager page11;
    public static AddProSupplier page12;
    public static AddAdmin page13;
    public static AddCatalogue page14;
    public static ManageCatItem page15;



    public static void main(String[] args) {
        ImportFile.importAdmin();
        ImportFile.importProManager();
        ImportFile.importSupplier();
        ImportFile.importProduct();
        ImportFile.importCatalogue();
        page1 = new Login();
        page2 = new DashboardAdmin();
        page3 = new DashboardManager();
        page4 = new ManageProduct();
        page5 = new ManageProManager();
        page6 = new ManageSupplier();
        page7 = new ManageAdmin();
        page8 = new ManageCatalogue();
        page9 = new ManagePersonalProfile();
        page10 = new AddProduct();
        page11 = new AddProManager();
        page12 = new AddProSupplier();
        page13 = new AddAdmin();
        page14 = new AddCatalogue();
        page15 = new ManageCatItem();
        

    }
    
}
