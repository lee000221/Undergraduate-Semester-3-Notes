package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import oodjassignment.ConfigurationUtilities;
import oodjassignment.Manager;
import oodjassignment.ManagerManage;
import oodjassignment.Main;

public class AdministratorUI extends JDialog implements ActionListener, ListSelectionListener {
    ManagerManage mm = new ManagerManage();
    private final DefaultListModel<Manager> model = new DefaultListModel<>();
    private final JList<Manager> mlist = new JList<>(model);
    private JButton btnAdd, btnDelete, btnUpdate, btnBackToLogin, btnCancel;
    private JTextField txtID, txtName, txtPwd, txtDept;
    public AdministratorUI(JFrame parent) {
        super(parent);
	for (Manager m : ConfigurationUtilities.managers) {
            model.addElement(m);
	}
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
        JPanel lp = new JPanel();
        JPanel rp1 = new JPanel();
        JPanel rp2 = new JPanel();
        JPanel rp = new JPanel();
        rp.setLayout(new BoxLayout(rp, BoxLayout.Y_AXIS));
        lp.setLayout(new BorderLayout());
        lp.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        this.mlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        this.mlist.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
        this.mlist.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
		if (e.getClickCount()==2) {
		}
            }
	});
	this.mlist.addListSelectionListener(this);
	lp.add(new JScrollPane(mlist));
		
	GridLayout gl = new GridLayout(0,2);
	gl.setHgap(3);
	gl.setVgap(5);
	rp1.setLayout(gl);
	rp1.add(new JLabel("ID:"));
	txtID = new JTextField();
	txtID.setSize(110, 20);
	txtID.setBackground(Color.gray);
	txtID.setEditable(false);
	rp1.add(txtID);
	rp1.add(new JLabel("Name:"));
	txtName = new JTextField();
	txtName.setSize(110, 20);
	rp1.add(txtName);
	rp1.add(new JLabel("Password:"));
	txtPwd = new JTextField();
	txtPwd.setSize(110, 20);
	rp1.add(txtPwd);
	rp1.add(new JLabel("Department:"));
	txtDept = new JTextField();
	txtDept.setSize(110, 20);
	rp1.add(txtDept);
		
	rp2.setLayout(new BoxLayout(rp2, BoxLayout.Y_AXIS));
	rp2.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
	btnAdd = new JButton("Add");
	btnAdd.setSize(60, 20);
	btnAdd.addActionListener(this);
	btnAdd.setToolTipText("Note: ID will be generated automatically");
	rp2.add(btnAdd);
	btnDelete = new JButton("Delete");
	btnDelete.setSize(60, 20);
	btnDelete.addActionListener(this);
	btnDelete.setToolTipText("Delete currently selected Manager");
	rp2.add(btnDelete);
	btnUpdate = new JButton("Update");
	btnUpdate.setSize(60, 20);
	btnUpdate.addActionListener(this);
	btnUpdate.setToolTipText("Note: ID cannot be changed");
	rp2.add(btnUpdate);
        btnBackToLogin = new JButton("Back To Login");
        btnBackToLogin.setSize(60,20);
        btnBackToLogin.addActionListener(this);
        rp2.add(btnBackToLogin);
        btnCancel = new JButton("Cancel");
        btnCancel.setSize(60,20);
        btnCancel.addActionListener(this);
        rp2.add(btnCancel);
        
	rp.add(rp1);
	rp.add(rp2);
	p.add(lp);
	p.add(rp);		
	this.add(p);
	this.setSize(600, 300);
        setLocationRelativeTo(null);

	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	this.setTitle("Manager Management");
		
	this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e){
                // Write files
                ConfigurationUtilities.writeManager();
            }
        });
        this.mlist.setSelectedIndex(0);
        //this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAdd) {
            // Add new manager
            String name = txtName.getText().trim();
            String pwd = txtPwd.getText().trim();
            String dept = txtDept.getText().trim();
            if (name.equals("") || pwd.equals("") || dept.equals("")) {
		JOptionPane.showMessageDialog(this, "Fields cannot be empty");
		return;
            }
            Manager m = new Manager(dept, name, pwd);
            if (this.mm.add(m) == 1) {
		this.model.addElement(m);
		this.mlist.setSelectedIndex(this.model.size()-1);
		JOptionPane.showMessageDialog(this, "Manager is added successfully");
            }
            else {
		JOptionPane.showMessageDialog(this, "Manager with the same ID already exists");
            }
        }
        else if (e.getSource() == btnDelete) {
            // Delete a manager
            String id = txtID.getText().trim();
            int res = JOptionPane.showConfirmDialog(this, "Are you sure to delete Manager with ID=" + id + "?");
            if (res == JOptionPane.YES_OPTION) {
		this.model.removeElementAt(this.mlist.getSelectedIndex());
		this.mm.delete(id);
		this.mlist.setSelectedIndex(0);
		JOptionPane.showMessageDialog(this, "Manager with ID "+id+" is removed");
            }			
	}
	else if (e.getSource() == btnUpdate) {
            // Update a manager
            String id = txtID.getText().trim();
            Manager m = this.model.getElementAt(this.mlist.getSelectedIndex());
            m.setName(txtName.getText().trim());
            m.setDepartment(txtDept.getText().trim());
            m.setPassword(txtPwd.getText().trim());
            this.model.addElement(m);
            this.mlist.setSelectedIndex(this.model.size()-1);

            JOptionPane.showMessageDialog(this, "Manager with ID "+id+" is updated");
	}
        else if (e.getSource() == btnBackToLogin){
            this.setVisible(false);
            new Login();
        }
        else if (e.getSource() == btnCancel){
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        }
    }
    public static void main(String args[]) throws Exception {
	Main.main(null);
	new AdministratorUI(null);
    }
    @Override
    public void valueChanged(ListSelectionEvent e) {
	int index = e.getFirstIndex();
	if (index >= 0) {
            Manager m = mlist.getSelectedValue();
            if (m!=null) {
		this.txtID.setText(m.getid());
                this.txtName.setText(m.getName());
		this.txtPwd.setText(m.getPassword());
		this.txtDept.setText(m.getDepartment());
            }
	}
    }	
}
