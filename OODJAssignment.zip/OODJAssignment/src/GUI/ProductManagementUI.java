package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import oodjassignment.ConfigurationUtilities;
import oodjassignment.Main;
import oodjassignment.Product;
import oodjassignment.Product.SuppliedProduct;
import oodjassignment.ProductManage;
import oodjassignment.Supplier;
import oodjassignment.SupplierManage;

import java.io.FileOutputStream;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import javax.swing.Box;

public class ProductManagementUI extends JDialog implements ActionListener, ListSelectionListener  {
    ProductManage pm = new ProductManage();
    private final DefaultListModel<Product> model = new DefaultListModel<>();
    private final JList<Product> mlist = new JList<>(model);
    private JButton btnAddProduct, btnDelete, btnSearch, btnPrintToPdf, btnUpdate, btnAddSupplier,btnBackToLogin, btnCancel;
    private JTextField txtID, txtName;
    private JComboBox cmbSupplierName;
    private JTextField txtPrice;	
    private JTextField txtDiscount ;
    private JTextField txtQuantity ;
    private JTextField txtWeight ;

    public ProductManagementUI(JFrame parent) {
        super(parent);
	for (Product m : ConfigurationUtilities.products) {
            model.addElement(m);
	}
			
        JPanel p = new JPanel();
	p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
        JPanel lp = new JPanel();
	JPanel rp1 = new JPanel();
	JPanel rp2 = new JPanel();
	JPanel rp = new JPanel();
	rp.setLayout(new BoxLayout(rp, BoxLayout.Y_AXIS));
			
	lp.setLayout(new BorderLayout());
        lp.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	this.mlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	this.mlist.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
	this.mlist.addListSelectionListener(this);
	lp.add(new JScrollPane(mlist));
			
        GridLayout gl = new GridLayout(0,2);
	gl.setHgap(3);
	gl.setVgap(5);
	rp1.setLayout(gl);
	rp1.add(new JLabel("ID:"));
	txtID = new JTextField();
	txtID.setSize(110, 20);
	txtID.setBackground(Color.gray);
	txtID.setEditable(false);
	rp1.add(txtID);
	rp1.add(new JLabel("Name:"));
	txtName = new JTextField();
	txtName.setSize(110, 20);
	rp1.add(txtName);
	rp1.add(new JLabel("Supplier:"));
	cmbSupplierName = new JComboBox(ConfigurationUtilities.suppliers.toArray());
	cmbSupplierName.setSize(110, 20);
	cmbSupplierName.addActionListener(this);
	rp1.add(cmbSupplierName);
	rp1.add(new JLabel("Price:"));
	txtPrice = new JTextField();
	txtPrice.setSize(110, 20);
	rp1.add(txtPrice);			
	rp1.add(new JLabel("Discount:"));
	txtDiscount = new JTextField();
	txtDiscount.setSize(110, 20);
	rp1.add(txtDiscount);
	rp1.add(new JLabel("Quantity:"));
	txtQuantity = new JTextField();
	txtQuantity.setSize(110, 20);
	rp1.add(txtQuantity);
	rp1.add(new JLabel("Weight:"));
	txtWeight = new JTextField();
	txtWeight.setSize(110, 20);
	rp1.add(txtWeight);
					
	rp2.setLayout(new BoxLayout(rp2, BoxLayout.Y_AXIS));
	rp2.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
        
	btnAddProduct = new JButton("Add Product");
	btnAddProduct.setSize(60, 20);
	btnAddProduct.addActionListener(this);
	btnAddProduct.setToolTipText("Note: ID will be generated automatically");
	rp2.add(btnAddProduct);
	btnAddSupplier = new JButton("Add Supplier to Product");
	btnAddSupplier.setSize(60, 20);
	btnAddSupplier.addActionListener(this);
	btnAddSupplier.setToolTipText("Note: Product Name cannot be changed");
	rp2.add(btnAddSupplier);		
	btnDelete = new JButton("Delete");
	btnDelete.setSize(60, 20);
	btnDelete.addActionListener(this);
	btnDelete.setToolTipText("Delete currently selected Product");
	rp2.add(btnDelete);
	btnUpdate = new JButton("Update");
	btnUpdate.setSize(60, 20);
	btnUpdate.addActionListener(this);
	btnUpdate.setToolTipText("Note: ID cannot be changed");
	rp2.add(btnUpdate);
        btnSearch = new JButton("Search");
	btnSearch.setSize(60, 20);
	btnSearch.addActionListener(this);
	btnSearch.setToolTipText("Search by ID or Name");
	rp2.add(btnSearch);
        btnPrintToPdf = new JButton("Print to PDF File");
	btnPrintToPdf.setSize(60, 20);
	btnPrintToPdf.addActionListener(this);
	rp2.add(btnPrintToPdf);
        btnBackToLogin = new JButton("Back To Login");
        btnBackToLogin.setSize(60,20);
        btnBackToLogin.addActionListener(this);
        rp2.add(btnBackToLogin);
        btnCancel = new JButton("Cancel");
	btnCancel.addActionListener(this);
	btnCancel.setBounds(190, 130, 60, 20);
        rp2.add(btnCancel);
        
	rp.add(rp1);
	rp.add(rp2);
	p.add(lp);
	p.add(rp);		
	this.add(p);
	this.setSize(630, 500);
        setLocationRelativeTo(null);
	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	this.setTitle("Product Management");
	this.addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent e){
                // Write files
	        ConfigurationUtilities.writeProduct();
	    }
	});
	this.mlist.setSelectedIndex(0);
        this.setModal(true);
        this.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.btnAddProduct) {
            // Add new product
            String name = txtName.getText().trim();
            String price = (txtPrice.getText().trim());
            String discount = (txtDiscount.getText().trim());
            String quantity = (txtQuantity.getText().trim());
            String weight = (txtWeight.getText().trim());
            if (name.equals("")  ) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty");
                return;
            }
            Product p = new Product();
            p.setName(name);
            Supplier s = (Supplier) this.cmbSupplierName.getSelectedItem();
            p.addOrUpdateSupplier(s.getID(), price, discount, quantity, weight);
            if (this.pm.add(p) == 1) {
		this.model.addElement(p);
		this.mlist.setSelectedIndex(this.model.size()-1);
		JOptionPane.showMessageDialog(this, "Product is added successfully");
            }
            else {
		JOptionPane.showMessageDialog(this, "Product with the same ID already exists");
            }
	}
	else if (e.getSource() == this.btnAddSupplier) {
            // Add a supplier information for the product
            Product p = null;
            String id = this.txtID.getText().trim();
            if (id.equals("")) {
		// add new product
		p = new Product();
		String name = this.txtName.getText().trim();
		if (name.equals("")) {
                    JOptionPane.showMessageDialog(this, "Name cannot be empty");
                    return;
		}
		this.pm.add(p);
		this.model.addElement(p);
		this.mlist.setSelectedIndex(this.model.size()-1);
            }
            else {
		// add supplier for current product
		p = (Product) this.pm.find(id);
            }
            String price = (txtPrice.getText().trim());
            String discount = (txtDiscount.getText().trim());
            String quantity = (txtQuantity.getText().trim());
            String weight = (txtWeight.getText().trim());
            Supplier s = (Supplier) this.cmbSupplierName.getSelectedItem();
            p.addOrUpdateSupplier(s.getID(), price, discount, quantity, weight);
            JOptionPane.showMessageDialog(this, "Supplier " + s.getName() + " is added to product " + p.getName());
	}
	else if (e.getSource() == this.btnDelete) {
            // Delete a product
            String id = txtID.getText().trim();
            int res = JOptionPane.showConfirmDialog(this, "Are you sure to delete Product with ID=" + id + "?");
            if (res == JOptionPane.YES_OPTION) {
		this.model.removeElementAt(this.mlist.getSelectedIndex());
		this.pm.delete(id);
		this.mlist.setSelectedIndex(0);
		JOptionPane.showMessageDialog(this, "Product with ID "+id+" is removed");
            }			
	}
	else if (e.getSource() == this.btnUpdate) {
            // Update a product
            System.out.println("123");
            String id = txtID.getText().trim();
            Product p = this.model.getElementAt(this.mlist.getSelectedIndex());
            p.setName(txtName.getText().trim());
            String price = (txtPrice.getText().trim());
            String discount = (txtDiscount.getText().trim());
            String quantity = (txtQuantity.getText().trim());
            String weight = (txtWeight.getText().trim());
            Supplier s = (Supplier) this.cmbSupplierName.getSelectedItem();
            p.addOrUpdateSupplier(s.getID(), price, discount, quantity, weight);
            this.model.setElementAt(p, this.mlist.getSelectedIndex());
            JOptionPane.showMessageDialog(this, "Manager with ID "+id+" is updated");
	}
	else if (e.getSource() == btnSearch) {
            // Search a Product
            JTextField tid = new JTextField(10);
            JTextField tname = new JTextField(10);
            JPanel panel = new JPanel();
            panel.add(new JLabel("ID: "));
            panel.add(tid);
            panel.add(Box.createHorizontalStrut(15)); // a spacer
            panel.add(new JLabel("Name: "));
            panel.add(tname);

            int res = JOptionPane.showConfirmDialog(this, panel, "Enter Product ID or Name", JOptionPane.OK_CANCEL_OPTION);
                if (res == JOptionPane.OK_OPTION) {
                    String id = tid.getText().trim();
                    String name = tname.getText().trim();
                    if (!id.equals("")) {
			Product p = (Product) this.pm.find(id) ;
			if (p != null) {
			    JOptionPane.showConfirmDialog(this, p.writeText(), "Product Information", JOptionPane.OK_CANCEL_OPTION);
                        }
			else {
			    JOptionPane.showMessageDialog(this, "Product with ID "+id+" does not exist");
			}			        	 
                    }
                    else if (!name.equals("")) {
			Product p = this.pm.findProductByName(name);
			if (p != null) {
                            JOptionPane.showConfirmDialog(this, p.writeText(), "Product Information", JOptionPane.OK_CANCEL_OPTION);
			}
			else {
			    JOptionPane.showMessageDialog(this, "Product with Name "+name+" does not exist");
			}	
                    }
                }
            }
	else if (e.getSource() == this.cmbSupplierName) {
            if (!this.txtID.getText().equals("")) {
		Product p = this.model.getElementAt(this.mlist.getSelectedIndex());
                Supplier s = (Supplier) this.cmbSupplierName.getSelectedItem();
		SuppliedProduct sp = p.getSuppliedProductBySuppliedID(s.getID());
		if (sp != null) {						
                    this.txtDiscount.setText(""+sp.getDiscount());
                    this.txtPrice.setText(""+sp.getPrice());
                    this.txtQuantity.setText(""+sp.getQuantity());
                    this.txtWeight.setText(""+sp.getWeight());
		}
		else {
                    this.txtDiscount.setText("");
                    this.txtPrice.setText("");
                    this.txtQuantity.setText("");
                    this.txtWeight.setText("");
		}
            }
	}
        else if(e.getSource() == this.btnPrintToPdf){

            try{
                Document document = new Document();
                PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Product.pdf"));
                document.open();
                PdfContentByte cb = writer.getDirectContent();
                cb.beginText();
                BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA,
                BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                cb.setFontAndSize(bf, 20);
                cb.setRGBColorFill(0xcc, 0x66, 0x66);
                cb.showTextAligned(Element.ALIGN_LEFT,"Product Information: " , 36, 800, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Product ID: " + txtID.getText().trim(), 36, 780, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Product Name: " + txtName.getText().trim(), 36, 760, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Supplier: " + (Supplier) this.cmbSupplierName.getSelectedItem(), 36, 740, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Product Price: " + txtPrice.getText().trim(), 36, 720, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Product Discount: " + txtDiscount.getText().trim(), 36, 700, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Product Quantity: " + txtQuantity.getText().trim(), 36, 680, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Product Weight: " + txtWeight.getText().trim(), 36, 660, 0);
                JOptionPane.showMessageDialog(this, "The Selected Product information has been updated in the PDF file!");

                cb.endText();
                document.close();
            } 
            catch (Exception x){
                System.out.println(x);
            }
        }
        else if (e.getSource() == this.btnBackToLogin){
            this.setVisible(false);
            new Login();
        }
        else if (e.getSource() == this.btnCancel){
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        }
    }
    public static void main(String args[]) throws Exception {
	Main.main(null);
	new ProductManagementUI(null);
    }
    @Override
    public void valueChanged(ListSelectionEvent e) {
        int index = e.getFirstIndex();
	if (index >= 0) {
            Product m = mlist.getSelectedValue();
            if (m!=null) {
                this.txtID.setText(m.getID());
		this.txtName.setText(m.getName());
		SupplierManage sm = new SupplierManage();
		Supplier s = (Supplier) sm.find(m.getSupplierIDs()[0].toString());
		this.cmbSupplierName.setSelectedIndex(ConfigurationUtilities.suppliers.indexOf(s));
            }
	}
    }
}
