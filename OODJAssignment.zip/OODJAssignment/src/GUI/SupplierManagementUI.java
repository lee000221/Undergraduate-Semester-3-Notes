package GUI;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileOutputStream;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import oodjassignment.ConfigurationUtilities;
import oodjassignment.Main;
import oodjassignment.Supplier;
import oodjassignment.SupplierManage;

public class SupplierManagementUI extends JDialog implements ActionListener, ListSelectionListener {
    SupplierManage sm = new SupplierManage();
    private final DefaultListModel<Supplier> model = new DefaultListModel<>();
    private final JList<Supplier> mlist = new JList<>(model);
    private JButton btnAdd, btnDelete, btnUpdate, btnPrintSupplierInfo, btnBackToLogin, btnCancel;
    private JTextField txtID, txtName, txtEmail, txtCountry, txtBlock, txtAddress, txtPhoneNumber;

    public SupplierManagementUI(JFrame parent) {
	super(parent);
	for (Supplier m : ConfigurationUtilities.suppliers) {
            model.addElement(m);
	}
			
	JPanel p = new JPanel();
	p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
	JPanel lp = new JPanel();
	JPanel rp1 = new JPanel();
	JPanel rp2 = new JPanel();
	JPanel rp = new JPanel();
	rp.setLayout(new BoxLayout(rp, BoxLayout.Y_AXIS));
						
	lp.setLayout(new BorderLayout());
	lp.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	this.mlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	this.mlist.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));		
	this.mlist.addListSelectionListener(this);
	lp.add(new JScrollPane(mlist));
			
	GridLayout gl = new GridLayout(0,2);
	gl.setHgap(3);
	gl.setVgap(5);
	rp1.setLayout(gl);
	rp1.add(new JLabel("ID:"));
	txtID = new JTextField();
	txtID.setSize(110, 20);
	txtID.setBackground(Color.gray);
	txtID.setEditable(false);
	rp1.add(txtID);
	rp1.add(new JLabel("Name:"));
	txtName = new JTextField();
	txtName.setSize(110, 20);
	rp1.add(txtName);
	rp1.add(new JLabel("Country:"));
	txtCountry = new JTextField();
	txtCountry.setSize(110, 20);
	rp1.add(txtCountry);
	rp1.add(new JLabel("Address:"));
	txtAddress = new JTextField();
	txtAddress.setSize(110, 20);
	rp1.add(txtAddress);
	rp1.add(new JLabel("Phone Number:"));
	txtPhoneNumber = new JTextField();
	txtPhoneNumber.setSize(110, 20);
	rp1.add(txtPhoneNumber);
        rp1.add(new JLabel("Email:"));
	txtEmail = new JTextField();
	txtEmail.setSize(110, 20);
	rp1.add(txtEmail);
			
	rp2.setLayout(new BoxLayout(rp2, BoxLayout.Y_AXIS));
	rp2.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
	btnAdd = new JButton("Add");
	btnAdd.setSize(60, 20);
	btnAdd.addActionListener(this);
	btnAdd.setToolTipText("Note: ID will be generated automatically");
	rp2.add(btnAdd);
	btnDelete = new JButton("Delete");
	btnDelete.setSize(60, 20);
	btnDelete.addActionListener(this);
	btnDelete.setToolTipText("Delete currently selected Supplier");
	rp2.add(btnDelete);
	btnUpdate = new JButton("Update");
	btnUpdate.setSize(60, 20);
	btnUpdate.addActionListener(this);
	btnUpdate.setToolTipText("Note: ID cannot be changed");
	rp2.add(btnUpdate);
        btnPrintSupplierInfo = new JButton("Print Supplier Information");
	btnPrintSupplierInfo.setSize(60, 20);
	btnPrintSupplierInfo.addActionListener(this);
	rp2.add(btnPrintSupplierInfo);
	btnBackToLogin = new JButton("Back To Login");
        btnBackToLogin.setSize(60,20);
        btnBackToLogin.addActionListener(this);
        rp2.add(btnBackToLogin);
        btnCancel = new JButton("Cancel");
        btnCancel.setSize(60,20);
        btnCancel.addActionListener(this);
        rp2.add(btnCancel);
        
	rp.add(rp1);
	rp.add(rp2);
	p.add(lp);
	p.add(rp);		
	this.add(p);
	this.setSize(600, 380);
        setLocationRelativeTo(null);
	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	this.setTitle("Supplier Management");
			
	this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e){
                // Write files
	        ConfigurationUtilities.writeSupplier();
	    }
	});
	this.mlist.setSelectedIndex(0);
	this.setModal(true);
	this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
	if (e.getSource() == btnAdd) {
            // Add new manager  txtEmail, txtCountry, txtAddress, txtPhoneNumber;
            String ID = this.txtID.getText().trim();
            String name = this.txtName.getText().trim();
            String address = this.txtAddress.getText().trim();
            String email = this.txtEmail.getText().trim();
            String country = txtCountry.getText().trim();				
            String phone = txtPhoneNumber.getText().trim();
								
            if (name.equals("") || address.equals("") || email.equals("") || country.equals("") || phone.equals("")) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty");
		return;
            }
            Supplier p = new Supplier(ID, name, country, address, phone, email);
            if (this.sm.add(p) == 1) {
                this.model.addElement(p);
		this.mlist.setSelectedIndex(this.model.size()-1);
		JOptionPane.showMessageDialog(this, "Supplier is added successfully");
            }
	}
	else if (e.getSource() == btnDelete) {
            // Delete a supplier
            String id = txtID.getText().trim();
            int res = JOptionPane.showConfirmDialog(this, "Are you sure to delete Supplier with ID=" + id + "?");
            if (res == JOptionPane.YES_OPTION) {
            this.model.removeElementAt(this.mlist.getSelectedIndex());
            this.sm.delete(id);
            this.mlist.setSelectedIndex(0);
            JOptionPane.showMessageDialog(this, "Supplier with ID "+id+" is removed");
            }			
	}
	else if (e.getSource() == btnUpdate) {
            // Update a manager
            String id = txtID.getText().trim();
            Supplier s = this.model.getElementAt(this.mlist.getSelectedIndex());
            s.setAddress(txtAddress.getText().trim());
            s.setCountry(txtCountry.getText().trim());
            s.setEmail(txtEmail.getText().trim());
            s.setName(txtName.getText().trim());
            s.setPhoneNumber(txtPhoneNumber.getText().trim());
            this.model.setElementAt(s, this.mlist.getSelectedIndex());
				
            JOptionPane.showMessageDialog(this, "Supplier with ID "+id+" is updated");
        }
        else if (e.getSource() == btnPrintSupplierInfo){
            try{
                Document document = new Document();
                PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Supplier.pdf"));
                document.open();
                PdfContentByte cb = writer.getDirectContent();
                cb.beginText();
                BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA,
                BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                cb.setFontAndSize(bf, 20);
                cb.setRGBColorFill(0xcc, 0x66, 0x66);
                cb.showTextAligned(Element.ALIGN_LEFT,"Supplier Information: " , 36, 800, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Supplier ID: " + txtID.getText().trim(), 36, 780, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Supplier Name: " + txtName.getText().trim(), 36, 760, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Supplier Address: " + txtAddress.getText().trim(), 36, 740, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Supplier Country: " + txtCountry.getText().trim(), 36, 720, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Supplier Email: " + txtEmail.getText().trim(), 36, 700, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Supplier Phone number: " + txtPhoneNumber.getText().trim(), 36, 680, 0);
                JOptionPane.showMessageDialog(this, "The Selected Supplier information has been updated in the PDF file!");

                cb.endText();
                document.close();
            } 
            catch (Exception x){
                System.out.println(x);
            }
        }
        else if (e.getSource() == btnCancel){
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        }
        else if (e.getSource() == btnBackToLogin){
            this.setVisible(false);
            new Login();
        }
    }
    public static void main(String args[]) throws Exception {
	Main.main(null);
	new SupplierManagementUI(null);
    }
    @Override
    public void valueChanged(ListSelectionEvent e) {
	int index = e.getFirstIndex();
	if (index >= 0) {
            Supplier s = mlist.getSelectedValue();
            if (s != null) {
		this.txtID.setText(s.getID());
		this.txtName.setText(s.getName());
		this.txtPhoneNumber.setText(s.getPhoneNumber());
		this.txtAddress.setText(s.getAddress());
                this.txtCountry.setText(s.getCountry());
		this.txtEmail.setText(s.getEmail());
            }
	}
    }
}
