package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import oodjassignment.ConfigurationUtilities;
import oodjassignment.Festival;
import oodjassignment.Main;
import oodjassignment.Product;
import oodjassignment.ProductManage;
import oodjassignment.Supplier;
import oodjassignment.SupplierManage;
import oodjassignment.Product.SuppliedProduct;

public class SelectFestivalUI extends JDialog implements ActionListener {	
    private final DefaultListModel<Festival> model = new DefaultListModel<>();
    private final JList<Festival> mlist = new JList<>(model);
    private JButton btnOK, btnCancel;
    private Festival selected = null;
	
    public SelectFestivalUI(JFrame parent) {
        super(parent);
	for (Festival f : ConfigurationUtilities.festivals) {
            model.addElement(f);
        }
		
	JPanel p = new JPanel();
	p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
	JPanel lp = new JPanel();
	JPanel rp = new JPanel();
	rp.setLayout(new BoxLayout(rp, BoxLayout.Y_AXIS));
	lp.setLayout(new BorderLayout());
	lp.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	
	this.mlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	this.mlist.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
	lp.add(new JScrollPane(mlist));
	
	rp.setLayout(new BoxLayout(rp, BoxLayout.Y_AXIS));
	rp.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
	btnOK = new JButton("OK");
	btnOK.setSize(60, 20);
	btnOK.addActionListener(this);
	rp.add(btnOK);
		
	btnCancel = new JButton("Cancel");
	btnCancel.setSize(60, 20);
	btnCancel.addActionListener(this);
	
	rp.add(btnCancel);
	p.add(lp);
	p.add(rp);		
	this.add(p);
	this.setSize(600, 300);
        setLocationRelativeTo(null);
	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	this.setTitle("Select Festival");
	if (model.size() > 0) {
            this.mlist.setSelectedIndex(0);
	}
	this.setModal(true);
	this.setVisible(true);
    }
    public Festival getSelectedFestival() {
	return this.selected;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
	if (e.getSource() == btnOK) {
            this.selected = this.mlist.getSelectedValue();
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
	else if (e.getSource() == btnCancel) {
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
    }
	
    public static void main(String args[]) throws Exception {
	Main.main(null);
		
	new SelectFestivalUI(null);
    }
}
