package GUI;
import oodjassignment.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.time.LocalDateTime;

/* The login GUI */
public class Login extends JFrame implements ActionListener {
    private JButton btnLogin;
    private JButton btnCancel;
    private JRadioButton rbtAdmin, rbtMng;	
    private JTextField txtID;
    private JPasswordField txtPwd;
	
    public Login() {
	this.setSize(300, 200);
        setLocationRelativeTo(null);

	JLabel lblID = new JLabel("Enter ID:");
	lblID.setBounds(40, 30, 100, 20);
	JLabel lblPwd = new JLabel("Enter Password:");
	lblPwd.setBounds(40, 55, 100, 20);
		
	txtID = new JTextField();
	txtID.setBounds(140, 30, 110, 20);
	txtPwd = new JPasswordField();
	txtPwd.setBounds(140, 55, 110, 20);
	txtPwd.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    Login.this.doLogin();
                }
            }
	});			
	btnLogin = new JButton("Login");
	btnLogin.addActionListener(this);
	btnLogin.setBounds(50, 130, 60, 20);
	btnCancel = new JButton("Cancel");
	btnCancel.addActionListener(this);
	btnCancel.setBounds(190, 130, 60, 20);
		
	rbtAdmin = new JRadioButton("Administrator");
	rbtMng = new JRadioButton("Product Manager");
	rbtMng.setSelected(true);
	rbtAdmin.setBounds(10, 90, 140, 20);
	rbtMng.setBounds(150, 90, 140, 20);
	ButtonGroup bg = new ButtonGroup();
	bg.add(rbtAdmin);
	bg.add(rbtMng);
		
	this.setLayout(null);
	this.add(lblID);
	this.add(lblPwd);
	this.add(txtID);
	this.add(txtPwd);
	this.add(btnLogin);
	this.add(btnCancel);
	this.add(rbtMng);
	this.add(rbtAdmin);
		
	this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e){
                // Write files
            	ConfigurationUtilities.writeLoginRecord();
            }
        });
	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	this.setVisible(true);
    }
	
    private void doLogin() {
	String id = this.txtID.getText().trim();
	char[] pwd = this.txtPwd.getPassword();
	if (id.equals("") || pwd.length==0) {
            JOptionPane.showMessageDialog(this, "Empty User Name or Password!");
            return;
	}
	Administrator admin = null;
	Manager mng = null;
	if (this.rbtAdmin.isSelected()) {
            // Administrator login				
            for (Administrator a : ConfigurationUtilities.administrators) {
                if (a.getid().equals(id)) {
                    admin = a;
                    break;
		}
            }
            if (admin != null && admin.login(id, pwd)) {
		// login successfully
		Main.admin = admin;
		LoginRecord r = new LoginRecord(id, "admin", LocalDateTime.now().toString(), true);
		ConfigurationUtilities.loginrecords.add(r);
		// show end-user(manager) management UI
		//new ManagerManagementUI(this);
                Main.login.setVisible(false);
                Main.AdministratorUI.setVisible(true);
            }
            else {
		// login failed
		LoginRecord r = new LoginRecord(id, "admin", LocalDateTime.now().toString(), false);
		ConfigurationUtilities.loginrecords.add(r);
		JOptionPane.showMessageDialog(this, "Wrong User Name or Password!");
            }		
	}
	else {
            // Manager login
            for (Manager m : ConfigurationUtilities.managers) {
                if (m.getid().equals(id)) {
                    mng = m;
                    break;
		}
            }
            if (mng != null && mng.login(id, pwd)) {
		// login successfully
		Main.manager = mng;	
		LoginRecord r = new LoginRecord(id, "manager", LocalDateTime.now().toString(), true);
		ConfigurationUtilities.loginrecords.add(r);
                this.setVisible(false);
		String[] ops = {"Supplier Management",  "Product Management", "Festival Management", "Catalogue Management"};
                int x = JOptionPane.showOptionDialog(this, "Select an option", "Manager", JOptionPane.DEFAULT_OPTION, 
                                                    JOptionPane.INFORMATION_MESSAGE, null, ops, ops[0]);
                if (x==0) {
                    // show supplier management UI
                    this.setVisible(false);
                    new SupplierManagementUI(this);
                }
                else if (x==2) {
                    this.setVisible(false);
                    // show festival Management UI
                    new FestivalManagementUI(this);
                }
                else if (x==1) {
                    this.setVisible(false);
                    // show product management UI
                    new ProductManagementUI(this);
                }
                else if (x==3) {
                    this.setVisible(false);
                    // show catalogue management UI
                    new CatalogueManagementUI();
                }
                if (x>=0 && x<=3) {
                    // close window
                    this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
                }
            }
            else {
                // login failed
                LoginRecord r = new LoginRecord(id, "manager", LocalDateTime.now().toString(), false);
                ConfigurationUtilities.loginrecords.add(r);
                JOptionPane.showMessageDialog(this, "Wrong User Name or Password!");
            }								
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        //if enter cancel close window
        if (e.getSource() == this.btnCancel) {
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
        //if enter login go to login gui
	else if (e.getSource() == this.btnLogin) {
            this.doLogin();			
	}
    }
	
    public static void main(String args[]) {
	new Login();
    }	
}
