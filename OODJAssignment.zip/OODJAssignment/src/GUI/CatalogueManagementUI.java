package GUI;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import oodjassignment.Catalogue;
import oodjassignment.CatalogueManage;
import oodjassignment.ConfigurationUtilities;
import oodjassignment.Festival;
import oodjassignment.Itemized;
import oodjassignment.Main;
import oodjassignment.Product;

public class CatalogueManagementUI extends JFrame implements ActionListener, ListSelectionListener  {
    CatalogueManage cm = new CatalogueManage();
	
    private final DefaultListModel<Catalogue> modelCatalogue = new DefaultListModel<>();
    private final JList<Catalogue> listCatalogue = new JList<>(modelCatalogue);
    private final DefaultListModel<Product> modelProduct = new DefaultListModel<>();
    private final JList<Product> listProduct= new JList<>(modelProduct);
    private final DefaultListModel<Festival> modelFestival = new DefaultListModel<>();
    private final JList<Festival> listFestival= new JList<>(modelFestival);
    private JButton btnAddCatalogue, btnDeleteCatalogue, btnUpdateCatalogue;
    private JButton btnAddProductForCatalogue, btnDeleteProductForCatalogue;
    private JButton btnAddFestivalForCatalogue, btnDeleteFestivalForCatalogue;
    private JButton btnPrintCatalogueInfo, btnBackToLoginPage, btnExit;
    private JTextField txtID, txtName;
	
    public CatalogueManagementUI() {
	for (Catalogue c : ConfigurationUtilities.catalogues) {
            this.modelCatalogue.addElement(c);
	}
	JPanel p = new JPanel();
	p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
	JPanel lp = new JPanel();
	JPanel rp1 = new JPanel();
	JPanel rp2 = new JPanel();
	JPanel rp = new JPanel();
	rp.setLayout(new BoxLayout(rp, BoxLayout.Y_AXIS));
		
	lp.setLayout(new GridLayout(1,3));
	lp.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
		
	this.listCatalogue.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	this.listCatalogue.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
	this.listCatalogue.addListSelectionListener(this);
	lp.add(new JScrollPane(this.listCatalogue));
	this.listProduct.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	this.listProduct.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
	this.listProduct.addListSelectionListener(this);
	lp.add(new JScrollPane(this.listProduct));
	this.listFestival.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	this.listFestival.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
	lp.add(new JScrollPane(this.listFestival));
		
	GridLayout gl = new GridLayout(0,2);
	gl.setHgap(3);
	gl.setVgap(5);
	rp1.setLayout(gl);
	rp1.add(new JLabel("ID:"));
	txtID = new JTextField();
	txtID.setSize(110, 20);
	txtID.setBackground(Color.gray);
	txtID.setEditable(false);
	rp1.add(txtID);
	rp1.add(new JLabel("Name:"));
	txtName = new JTextField();
	txtName.setSize(110, 20);
	rp1.add(txtName);
				
	rp2.setLayout(new BoxLayout(rp2, BoxLayout.Y_AXIS));
	rp2.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
		
	this.btnAddCatalogue = new JButton("Add Catalogue");
	this.btnAddCatalogue.setSize(60, 20);
	this.btnAddCatalogue.addActionListener(this);
	this.btnAddCatalogue.setToolTipText("Note: ID will be generated automatically");
	rp2.add(this.btnAddCatalogue);
		
	this.btnDeleteCatalogue = new JButton("Delete Catalogue");
	this.btnDeleteCatalogue.setSize(60, 20);
	this.btnDeleteCatalogue.addActionListener(this);
	this.btnDeleteCatalogue.setToolTipText("Delete current selected Catalogue");
	rp2.add(this.btnDeleteCatalogue);
		
	this.btnUpdateCatalogue = new JButton("Update Catalogue");
	this.btnUpdateCatalogue.setSize(60, 20);
	this.btnUpdateCatalogue.addActionListener(this);
	this.btnUpdateCatalogue.setToolTipText("Update current selected Catalogue");
	rp2.add(this.btnUpdateCatalogue);
		
	this.btnAddProductForCatalogue = new JButton("Add Product to Catalogue");
	this.btnAddProductForCatalogue.setSize(60, 20);
	this.btnAddProductForCatalogue.addActionListener(this);
	this.btnAddProductForCatalogue.setToolTipText("Add product to current selected Catalogue");
	rp2.add(this.btnAddProductForCatalogue);
		
	this.btnDeleteProductForCatalogue = new JButton("Delete Product from Catalogue");
	this.btnDeleteProductForCatalogue.setSize(60, 20);
	this.btnDeleteProductForCatalogue.addActionListener(this);
	this.btnDeleteProductForCatalogue.setToolTipText("Delete current selected product from the Catalogue");
	rp2.add(this.btnDeleteProductForCatalogue);
		
	this.btnAddFestivalForCatalogue = new JButton("Add festival to Catalogue");
	this.btnAddFestivalForCatalogue.setSize(60, 20);
	this.btnAddFestivalForCatalogue.addActionListener(this);
	this.btnAddFestivalForCatalogue.setToolTipText("Add festival to current selected Catalogue");
	rp2.add(this.btnAddFestivalForCatalogue);
		
	this.btnDeleteFestivalForCatalogue = new JButton("Delete festival of Catalogue");
	this.btnDeleteFestivalForCatalogue.setSize(60, 20);
	this.btnDeleteFestivalForCatalogue.addActionListener(this);
	this.btnDeleteFestivalForCatalogue.setToolTipText("Delete festival for current selected Catalogue");
	rp2.add(this.btnDeleteFestivalForCatalogue);  
        
        this.btnPrintCatalogueInfo = new JButton("Print Catalogue Information in pdf");
	this.btnPrintCatalogueInfo.setSize(60, 20);
	this.btnPrintCatalogueInfo.addActionListener(this);
        this.btnPrintCatalogueInfo.setToolTipText("The selected Catalogue Information has been updated!");
	rp2.add(this.btnPrintCatalogueInfo);
        
        this.btnBackToLoginPage = new JButton("Back to Login page");
	this.btnBackToLoginPage.setSize(60, 20);
	this.btnBackToLoginPage.addActionListener(this);
	rp2.add(this.btnBackToLoginPage);
	
        this.btnExit = new JButton("Exit");
	this.btnExit.setSize(60, 20);
	this.btnExit.addActionListener(this);
	rp2.add(this.btnExit);
        
	rp.add(rp1);
	rp.add(rp2);
	p.add(lp);
	p.add(rp);		
	this.add(p);
	this.setSize(730, 370);
        setLocationRelativeTo(null);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setTitle("Catalogue Management");
	this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e){
                // Write files
            	ConfigurationUtilities.writeCatalogue();
            }
        });
		
	if (this.modelCatalogue.size() > 0) {
            this.listCatalogue.setSelectedIndex(0);
        }		
	this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.btnAddCatalogue) {
            // Add new catalogue
            String name = txtName.getText().trim();
            if (name.equals("")  ) {
                JOptionPane.showMessageDialog(this, "Name cannot be empty");
		return;
            }	
            Catalogue c = new Catalogue();
            c.setName(name);	
            if (this.cm.add(c) == 1) {
		this.modelCatalogue.addElement(c);
		this.listCatalogue.setSelectedIndex(this.modelCatalogue.size()-1);
		JOptionPane.showMessageDialog(this, "Catalogue is added successfully");
            }
            else {
		JOptionPane.showMessageDialog(this, "Catalogue with the same ID already exists");
            }
        }
	else if (e.getSource() == this.btnDeleteCatalogue) {
            // Delete a Catelogue
            int ind = this.listCatalogue.getSelectedIndex();
            if (ind >= 0) {
		String id = txtID.getText().trim();
                int res = JOptionPane.showConfirmDialog(this, "Are you sure to delete Catalogue with ID=" + id + "?");		
		if (res == JOptionPane.YES_OPTION) {
                    this.modelCatalogue.removeElementAt(ind);
                    this.cm.delete(id);
                    this.listCatalogue.setSelectedIndex(0);
                    JOptionPane.showMessageDialog(this, "Catalogue with ID "+id+" is removed");
                    if (this.modelCatalogue.size() > 0) {
			this.listCatalogue.setSelectedIndex(0);
                    }
		}
            }
            else {
		JOptionPane.showMessageDialog(this, "No Catalogue");
            }
	}
	else if (e.getSource() == this.btnUpdateCatalogue) {
            // Update a Catalogue
            String id = txtID.getText().trim();
            Catalogue c = this.modelCatalogue.getElementAt(this.listCatalogue.getSelectedIndex());
            c.setName(txtName.getText().trim());		
            JOptionPane.showMessageDialog(this, "Catalogue with ID " + id + " is updated");
	}
	else if (e.getSource() == this.btnAddFestivalForCatalogue) {
            SelectFestivalUI dlg = new SelectFestivalUI(this);
            Festival f = dlg.getSelectedFestival();
            if (f!=null) {
		if (this.listCatalogue.getSelectedValue().addFestival(f)) {
                    this.modelFestival.addElement(f);
                    this.listFestival.setSelectedIndex(this.modelFestival.size()-1);
                }
                else {
		JOptionPane.showMessageDialog(this, "Festival " + f.getName() + " already exists");
                }
            
            }
        }
	else if (e.getSource() == this.btnAddProductForCatalogue) {
            SelectProductUI dlg = new SelectProductUI(this);
            Product p = dlg.getSelectedProduct();
            if (p!=null) {
		if (this.listCatalogue.getSelectedValue().addProduct(p)) {
                    this.modelProduct.addElement(p);
                    this.listProduct.setSelectedIndex(this.modelProduct.size()-1);
                }
                else {
		JOptionPane.showMessageDialog(this, "Product " + p.getName() + " already exists");
                }
            }
	}
	else if (e.getSource() == this.btnDeleteFestivalForCatalogue) {
            int ind = this.listFestival.getSelectedIndex();
            if (ind >= 0) {
		Festival f = this.modelFestival.get(ind);
		this.listCatalogue.getSelectedValue().removeFestival(f);
		this.modelFestival.remove(ind);
		if (this.modelFestival.size() > 0) {
                    this.listFestival.setSelectedIndex(0);
		}
                else{
                    this.modelFestival.clear();
                }
            }
            else {
                JOptionPane.showConfirmDialog(this, "No festivals");
            }
        }
        else if (e.getSource() == this.btnDeleteProductForCatalogue) {
            int ind = this.listProduct.getSelectedIndex();
            if (ind >= 0) {				
		Product p = this.modelProduct.get(ind);
		this.listCatalogue.getSelectedValue().removeProduct(p);
		this.modelProduct.remove(ind);
                if (this.modelProduct.size() > 0) {
                    this.listProduct.setSelectedIndex(0);
                }
                else{
                    this.modelProduct.clear();
                }
            }
            else {
		JOptionPane.showConfirmDialog(this, "No products");
            }
	}
        else if(e.getSource() == this.btnPrintCatalogueInfo){
        
            try{
                Document document = new Document();
                PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Catalogue.pdf"));
                document.open();
                PdfContentByte cb = writer.getDirectContent();
                cb.beginText();
                BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA,
                BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                cb.setFontAndSize(bf, 20);
                cb.setRGBColorFill(0xcc, 0x66, 0x66);
                cb.showTextAligned(Element.ALIGN_CENTER,"Catalogue Information" , 36, 800, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Catalogue ID: " + txtID.getText().trim(), 36, 760, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Catalogue Name: " + txtName.getText().trim(), 36, 720, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Product information: " + modelProduct, 36, 680, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Festival information: " + modelFestival, 36, 600, 0);

                JOptionPane.showMessageDialog(this, "The Selected Product information has been updated in the PDF file!");

                cb.endText();
                document.close();
            } 
            catch (Exception x){
                System.out.println(x);
            }
        }
        else if (e.getSource() == this.btnBackToLoginPage){
            //this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
            this.setVisible(false);
            new Login();
        }
        else if (e.getSource() == this.btnExit){
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        }
    }
    public static void main(String args[]) throws Exception {
	Main.main(null);
	new CatalogueManagementUI();
    }
    @Override
    public void valueChanged(ListSelectionEvent e) {
	if (e.getSource() == this.listCatalogue) {
            int index = this.listCatalogue.getSelectedIndex();
            if (index >= 0) {
                // show product information on selected catalogue 
                Catalogue c = this.listCatalogue.getSelectedValue();
		if (c != null) {
                    this.txtID.setText(c.getID());
                    this.txtName.setText(c.getName());	
                    // update product list
                    this.modelProduct.removeAllElements();
                    for (Itemized i : c.getProducts()) {
			this.modelProduct.addElement((Product)i);            
                    }
                    if (this.modelProduct.size() > 0) {
			this.listProduct.setSelectedIndex(0);
                    }				
                    // show festival information on selected catalogue 
                    // update festival list
                    this.modelFestival.removeAllElements();
                    for (Festival i : c.getFestival()) {
			this.modelFestival.addElement(i);             
                    }
                    if (this.modelFestival.size() > 0) {
			this.listFestival.setSelectedIndex(0);
                    }
		}
            }
	}	
    }	
}
