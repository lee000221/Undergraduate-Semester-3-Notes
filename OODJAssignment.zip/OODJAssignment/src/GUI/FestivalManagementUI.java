package GUI;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileOutputStream;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import oodjassignment.ConfigurationUtilities;
import oodjassignment.Festival;
import oodjassignment.FestivalManage;
import oodjassignment.Main;

public class FestivalManagementUI extends JDialog implements ActionListener, ListSelectionListener {
    FestivalManage fm = new FestivalManage();
    private final DefaultListModel<Festival> model = new DefaultListModel<>();
    private final JList<Festival> mlist = new JList<>(model);
    private JButton btnAdd, btnDelete, btnUpdate, btnPrintFestivalInfo, btnBackToLogin, btnExit;
    private JTextField txtID, txtName, txtDate;

    public FestivalManagementUI(JFrame parent) {
        super(parent);
	for (Festival f : ConfigurationUtilities.festivals) {
            model.addElement(f);
	}
        JPanel p = new JPanel();
	p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
	JPanel lp = new JPanel();
	JPanel rp1 = new JPanel();
	JPanel rp2 = new JPanel();
	JPanel rp = new JPanel();
        rp.setLayout(new BoxLayout(rp, BoxLayout.Y_AXIS));				
	lp.setLayout(new BorderLayout());
	lp.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	this.mlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	this.mlist.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
	this.mlist.addListSelectionListener(this);
	lp.add(new JScrollPane(mlist));			
	GridLayout gl = new GridLayout(0,2);
	gl.setHgap(3);
        gl.setVgap(5);
	rp1.setLayout(gl);
	rp1.add(new JLabel("ID:"));
	txtID = new JTextField();
	txtID.setSize(110, 20);
	txtID.setBackground(Color.gray);
	txtID.setEditable(false);
	rp1.add(txtID);
	rp1.add(new JLabel("Name:"));
	txtName = new JTextField();
	txtName.setSize(110, 20);
	rp1.add(txtName);
	rp1.add(new JLabel("Date:"));
	txtDate = new JTextField();
	txtDate.setSize(110, 20);
	rp1.add(txtDate);
				
	rp2.setLayout(new BoxLayout(rp2, BoxLayout.Y_AXIS));
	rp2.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
        btnAdd = new JButton("Add");
	btnAdd.setSize(60, 20);
	btnAdd.addActionListener(this);
	btnAdd.setToolTipText("Note: ID will be generated automatically");
	rp2.add(btnAdd);
	btnDelete = new JButton("Delete");
	btnDelete.setSize(60, 20);
	btnDelete.addActionListener(this);
	btnDelete.setToolTipText("Delete currently selected Supplier");
	rp2.add(btnDelete);
	btnUpdate = new JButton("Update");
	btnUpdate.setSize(60, 20);
	btnUpdate.addActionListener(this);
	btnUpdate.setToolTipText("Note: ID cannot be changed");
	rp2.add(btnUpdate);
        btnPrintFestivalInfo = new JButton("Print Festival Information in pdf");
        btnPrintFestivalInfo.setSize(60,20);
        btnPrintFestivalInfo.addActionListener(this);
        this.btnPrintFestivalInfo.setToolTipText("The selected Festival Information has been updated!");
        rp2.add(btnPrintFestivalInfo);
	btnBackToLogin = new JButton("Back To Login");
        btnBackToLogin.setSize(60,20);
        btnBackToLogin.addActionListener(this);
        rp2.add(btnBackToLogin);
        btnExit = new JButton("Exit");
        btnExit.setSize(60,20);
        btnExit.addActionListener(this);
        rp2.add(btnExit);
        
	rp.add(rp1);
	rp.add(rp2);
	p.add(lp);
	p.add(rp);		
	this.add(p);
	this.setSize(600, 300);
        setLocationRelativeTo(null);
	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setTitle("Festival Management");
        
	this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e){
		// Write files
		ConfigurationUtilities.writeFestival();
            }
	});
	this.mlist.setSelectedIndex(0);
        this.setModal(true);
	this.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
	if (e.getSource() == btnAdd) {
            // Add new festival
            String id = this.txtID.getText().trim();
            String name = this.txtName.getText().trim();
            String date = this.txtDate.getText().trim();
            if (name.equals("") || date.equals("")) {
		JOptionPane.showMessageDialog(this, "Fields cannot be empty");
                return;
            }			
            Festival f = new Festival();
            f.setID(id);
            f.setName(name);
            f.setDate(date);
            if (this.fm.add(f) == 1) {
		this.model.addElement(f);
		this.mlist.setSelectedIndex(this.model.size()-1);
		JOptionPane.showMessageDialog(this, "Festival is added successfully");
            }
            else {
		JOptionPane.showMessageDialog(this, "Product with the same ID already exists");
            }
	}
	else if (e.getSource() == btnDelete) {
            // Delete a festival
            String id = txtID.getText().trim();
            int res = JOptionPane.showConfirmDialog(this, "Are you sure to delete Festival " + txtName.getText() + "?");
            if (res == JOptionPane.YES_OPTION) {
		this.model.removeElementAt(this.mlist.getSelectedIndex());
		this.fm.delete(id);
		this.mlist.setSelectedIndex(0);
		JOptionPane.showMessageDialog(this, "Supplier with ID "+id+" is removed");
            }			
	}
	else if (e.getSource() == btnUpdate) {
            // Update a manager
            String id = txtID.getText().trim();
            Festival f = this.model.getElementAt(this.mlist.getSelectedIndex());
            f.setDate(this.txtDate.getText().trim());
            f.setName(this.txtName.getText().trim());
            this.model.setElementAt(f, this.mlist.getSelectedIndex());
					
            JOptionPane.showMessageDialog(this, "Festival "+f.getName()+" is updated");
	}
        else if (e.getSource() == btnPrintFestivalInfo){        
            try{
                Document document = new Document();
                PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Festival.pdf"));
                document.open();
                PdfContentByte cb = writer.getDirectContent();
                cb.beginText();
                BaseFont bf = BaseFont.createFont(BaseFont.HELVETICA,
                BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                cb.setFontAndSize(bf, 20);
                cb.setRGBColorFill(0xcc, 0x66, 0x66);
                cb.showTextAligned(Element.ALIGN_LEFT,"Festival Information: " , 36, 800, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Festival ID: " + txtID.getText().trim(), 36, 780, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Festival Name: " + txtName.getText().trim(), 36, 760, 0);
                cb.showTextAligned(Element.ALIGN_LEFT,"Festival Date: " + txtDate.getText().trim(), 36, 740, 0);
                JOptionPane.showMessageDialog(this, "The Selected Product information has been updated in the PDF file!");

                cb.endText();
                document.close();
            } 
            catch (Exception x){
                System.out.println(x);
            }   
        }
        else if (e.getSource() == btnBackToLogin){
            this.setVisible(false);
            new Login();
        }
        else if (e.getSource() == btnExit){
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        }
    }
    public static void main(String args[]) throws Exception {
	Main.main(null);
	new FestivalManagementUI(null);
    }
    
    @Override
    public void valueChanged(ListSelectionEvent e) {
	int index = e.getFirstIndex();
	if (index >= 0) {
            Festival f = this.mlist.getSelectedValue();
            if (f != null) {
                this.txtID.setText(f.getID());
                this.txtName.setText(f.getName());
                this.txtDate.setText(f.getDate());
            }
        }				
    }
}
