package GUI;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.function.Supplier;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JWindow;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;

import oodjassignment.ConfigurationUtilities;
import oodjassignment.Festival;
import oodjassignment.Main;
import oodjassignment.Product;

public class SelectProductUI extends JDialog implements ActionListener {
    private final DefaultListModel<Product> modelProduct= new DefaultListModel<>();
    private final JList<Product> listProduct = new JList<>(modelProduct);
    private JButton btnOK, btnCancel;
    private Product selected = null;

    public SelectProductUI(JFrame parent) {
	super(parent);
	for (Product p : ConfigurationUtilities.products) {
            this.modelProduct.addElement(p);
	}
	JPanel p = new JPanel();
	p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
	JPanel lp = new JPanel();
	JPanel rp = new JPanel();
	rp.setLayout(new BoxLayout(rp, BoxLayout.Y_AXIS));
	lp.setLayout(new BorderLayout());
	lp.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	this.listProduct.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	this.listProduct.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
	lp.add(new JScrollPane(listProduct));
        
	rp.setLayout(new BoxLayout(rp, BoxLayout.Y_AXIS));
	rp.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
	btnOK = new JButton("OK");
	btnOK.setSize(60, 20);
	btnOK.addActionListener(this);
	rp.add(btnOK);		
	btnCancel = new JButton("Cancel");
	btnCancel.setSize(60, 20);
	btnCancel.addActionListener(this);
	rp.add(btnCancel);
        
	p.add(lp);
	p.add(rp);		
	this.add(p);
	this.setSize(430, 300);
        setLocationRelativeTo(null);
	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	this.setTitle("Select Product");
			
	if (this.modelProduct.size() > 0) {
            this.listProduct.setSelectedIndex(0);
	}
			
	this.setModal(true);
	this.setVisible(true);
    }
    public Product getSelectedProduct() {
	return this.selected;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
	if (e.getSource() == btnOK) {
            this.selected = this.listProduct.getSelectedValue();
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
	else if (e.getSource() == btnCancel) {
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
    }
    public static void main(String args[]) throws Exception {
	Main.main(null);
	new SelectProductUI(null);
    }
}
