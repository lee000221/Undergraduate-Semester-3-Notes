
package oodjassignment;
//text write interface
public interface textWrite {
    String writeText();
}
