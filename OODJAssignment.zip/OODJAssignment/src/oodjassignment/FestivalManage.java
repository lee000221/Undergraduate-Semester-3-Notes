package oodjassignment;

import java.util.ArrayList;

public class FestivalManage implements Manageable{
    private ArrayList<Festival> festivals;
    
    public FestivalManage() {
        this.festivals = ConfigurationUtilities.festivals;
    }
    @Override
    public Object find(String id) {
	for (Festival f : this.festivals) {
            if (f.getID().equals(id)) {
		return f;
            }
	}
	return null;
    }
    @Override
    public int add(Object obj) {
	Festival f = (Festival) obj;
	if (f != null) {
            this.festivals.add(f);
            return 1;
	}
	else {
	return 0;
        }
    }
    @Override
    public int delete(String id) {
	Festival f = (Festival) this.find(id);
	if (f != null) {
            this.festivals.remove(f);
            return 1;
	}
	return 0;
    }
    @Override
    public void update(Object obj) {
        Festival s = (Festival) obj;
        if (s != null && this.find(s.getID()) != null) {
            this.festivals.remove(s);
            this.festivals.add(s);
            return;
	}
    }
}
