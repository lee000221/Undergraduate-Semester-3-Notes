
package oodjassignment;
import java.util.Collection;
import java.util.Set;
import java.util.TreeMap;
// A product could be supplied by several suppliers.
// Each supplier could have different price, discount, quantity, and weight for the same product.
public class Product implements Itemized, textRead, textWrite {
    private String ID;
    private String name;	
	
    public class SuppliedProduct implements textRead, textWrite {
        private String supplierID = "";
	private String price = "0.0";
	private String discount = "0.0";
	private String quantity = "0.0";
	private String weight = "0.0";
		
        public SuppliedProduct(String id) {
            this.supplierID = id;
	}
		
	public SuppliedProduct(String id, String price, String discount, String quantity, String weight) {
            this.supplierID = id;
            this.price = price;
            this.discount = discount;
            this.quantity = quantity;
            this.weight = weight;
	}
	public String getID() {
            return this.supplierID;
	}
		
	public String getPrice() {
            return price;
	}
	public void setPrice(String price) {
            this.price = price;
	}
	public String getDiscount() {
            return this.discount;
	}
	public void setDiscount(String discount) {
            this.discount = discount;
	}
	public void setQuantity(String quantity) {
            this.quantity = quantity;
	}
	public String getQuantity() {
            return this.quantity;
	}
	public void setWeight(String weight) {
            this.weight = weight;
	}
	public String getWeight() {
            return this.weight;
	}
	@Override
	public String toString() {
            return String.format("Product from supplier %s, price:%.2f discount:%.2f quantity: %d weight: %.2f", 
				this.getID(), this.getPrice(), this.getDiscount(), this.getQuantity(), this.getWeight());
	}
	@Override
	public String writeText() {
            String[] ss = { this.supplierID, ""+this.price, ""+this.discount, ""+this.quantity, ""+this.weight };
            return String.join(ConfigurationUtilities.fieldDelimeter, ss);
	}
	@Override
	public textRead readText(String txt) {
            String[] ss = txt.split(ConfigurationUtilities.fieldDelimeter);
		this.supplierID = ss[0].trim();
		this.setPrice((ss[1].trim()));
		this.setDiscount((ss[2].trim()));
		this.setQuantity(ss[3].trim());
		this.setWeight((ss[4].trim()));
		return (textRead)this.clone();
	}
	@Override
	public Object clone() {
            return new SuppliedProduct(this.getID(), this.getPrice(), this.getDiscount(), this.getQuantity(), this.getWeight());
	}
    }
	
    // key: supplier ID, value: product data
    private TreeMap<String, SuppliedProduct> suppliedProducts; 
    public Product() {
	this.ID = Product.GenerateProductID();
	this.suppliedProducts = new TreeMap<String, SuppliedProduct>();
    }
	
    private static String GenerateProductID() {
    // Auto generate UID
	String id = "0";
	if (ConfigurationUtilities.products != null) {
            for (Product p : ConfigurationUtilities.products) {
		if (Integer.parseInt(p.getID()) > Integer.parseInt(id)) {
                    id = p.getID();
		}
            }
	}
	id = "" + (Integer.parseInt(id) + 1);
        return id;
    }
    public Product(String id, String name) {
	this.ID = id;
	this.name = name;
	this.suppliedProducts = new TreeMap<String, SuppliedProduct>();
    }
	
    public Object[] getSupplierIDs() {
	return this.suppliedProducts.keySet().toArray();
    }
    public SuppliedProduct getSuppliedProductBySuppliedID(String sid) {
	if (this.suppliedProducts.containsKey(sid)) {
            return this.suppliedProducts.get(sid);
	}
	else {
            return null;
	}
    }
    public void addOrUpdateSupplier(String id, String price, String discount, String quantity, String weight) {
	if (this.suppliedProducts.containsKey(id)) {
            SuppliedProduct sp = this.suppliedProducts.get(id);
            sp.setDiscount(discount);
            sp.setPrice(price);
            sp.setQuantity(quantity);
            sp.setWeight(weight);
	}
	else {
            SuppliedProduct sp = new SuppliedProduct(id, price, discount, quantity, weight);
            this.suppliedProducts.put(sp.getID(), sp);
	}
    }
    public String getID() {
	return this.ID;
    }
    public void setName(String name) {
	this.name = name;
    }
    public String getName() {
	return this.name;
    }
    public String getPrice(String supplierid) {
	return this.suppliedProducts.get(supplierid).getPrice();
    }
    public String toString() {
	String[] as = { this.ID, this.name };
        String s = String.join(",", as);
        return s;
    }
    @Override
    public String writeText() {
    // return a colon separated string with all data member fields
	String ss[] = { this.getID(), this.getName() };
	String r = String.join(ConfigurationUtilities.fieldDelimeter, ss);
	for (SuppliedProduct sp : this.suppliedProducts.values()) {
            r = r + ConfigurationUtilities.fieldDelimeter + sp.writeText();
	}
	return r;
    }
    @Override
    public textRead readText(String txt) {
	String ss[] = txt.split(ConfigurationUtilities.fieldDelimeter);
	this.ID=ss[0].trim();
	this.setName(ss[1].trim());
	this.suppliedProducts.clear();
	for (int i = 2; i < ss.length; i += 5) {
            // one SuppliedProduct object has 5 attributes
            SuppliedProduct sp = new SuppliedProduct(ss[i].trim(), 
            (ss[i+1].trim()), (ss[i+2].trim()), 
            (ss[i+3].trim()), (ss[i+4].trim()));
            this.suppliedProducts.put(sp.getID(), sp);
	}
	return (textRead)this.clone();
    }
    public Object clone() {
	Product p = new Product(this.ID, this.name);
	for (SuppliedProduct sp : this.suppliedProducts.values()) {
            p.addOrUpdateSupplier(sp.getID(), sp.getPrice(), sp.getDiscount(), sp.getQuantity(), sp.getWeight());
	}
	return p;
    }
    public boolean equals(Object o) {
	Product p = (Product)o;
	return p.getID().equals(this.getID());
    }	
}

