package oodjassignment;

import java.util.ArrayList;
// The class manages products.
public class ProductManage implements Manageable {
    private ArrayList<Product> products;	
    public ProductManage() {
	this.products = ConfigurationUtilities.products;
    }
    public Product findProductByName(String name) {
	for (Product p : this.products) {
            if (p.getName().equals(name)) {
		return p;
            }
	}
	return null;
    }
    public ArrayList<Product> getProducts() {
	return this.products;
    }
    @Override
    public Object find(String pid) {
	for (Product p : this.products) {
            if (p.getID().equals(pid)) {
		return p;
            }
	}
	return null;
    }
    @Override
    public int add(Object obj) {
	Product p = (Product) obj;
        if (obj == null) {
            return 0;
	}
	else {
            this.products.add(p);
            return 1;
	}
    }
    @Override
    public int delete(String pid) {
	for (Product p : this.products) {
            if (p.getID().equals(pid)) {
		this.products.remove(p);
		return 1;
            }
        }
	return 0;
    }
    @Override
    public void update(Object obj) {
	Product p = (Product)obj;
        if (p==null) {
            System.out.println("Can not change Object to Product");
	}
	if (this.find(p.getID()) != null) {
            Product pold = (Product)this.find(p.getID());
            this.products.remove(pold);
            this.products.add(p);
	}
	else {			
            System.out.println("Update failed. Product not found");
	}	
    }
}
