
package oodjassignment;
// An itemized object could be added to a catalog.

public interface Itemized {
    String getID();
    String getName();
}
