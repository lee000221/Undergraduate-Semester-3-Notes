package oodjassignment;

public class LoginRecord implements textWrite, textRead {
    private String uid;
    private String type;
    private String datetime;
    private boolean success;
    
    public LoginRecord() {}
    public LoginRecord(String uid, String type, String datetime, boolean success) {
        this.uid = uid;
        this.type = type;
        this.datetime = datetime;
	this.success = success;
    }
    public String getUid() {
	return uid;
    }
    public void setUid(String uid) {
	this.uid = uid;
    }
    public String getDatetime() {
	return datetime;
    }
    public void setDatetime(String datetime) {
	this.datetime = datetime;
    }
    public String getType() {
	return type;
    }
    public void setType(String type) {
	this.type = type;
    }
    public boolean isSuccess() {
	return success;
    }
    public void setSuccess(boolean success) {
        this.success = success;
    }

    @Override
    public String writeText() {
	return String.join(ConfigurationUtilities.fieldDelimeter, new String[] {uid, type, datetime, success? "succeed":"failed"});
    }
    @Override
    public textRead readText(String txt) {
	String[] ss = txt.split(ConfigurationUtilities.fieldDelimeter);
	this.setUid(ss[0].trim());
	this.setType(ss[1].trim());
	this.setDatetime(ss[2].trim());
	this.setSuccess(ss[3].trim().equals("succeed"));
	return (textRead)this.clone();
    }
    public Object clone() {
	return new LoginRecord(this.uid, this.type, this.datetime, this.success);
    }
}
