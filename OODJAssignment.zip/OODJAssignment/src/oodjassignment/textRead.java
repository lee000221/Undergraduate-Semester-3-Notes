
package oodjassignment;
//text read interface
public interface textRead {
    textRead readText(String txt);
}
