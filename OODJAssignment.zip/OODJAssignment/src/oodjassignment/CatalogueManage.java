package oodjassignment;
import java.util.ArrayList;

public class CatalogueManage implements Manageable {
    private ArrayList<Catalogue> catalogues;
    public CatalogueManage() {
	this.catalogues = ConfigurationUtilities.catalogues;
    }
    @Override
    public Object find(String id) {
	for (Catalogue c : this.catalogues) {
            if (c.getID().equals(id)) {
		return c;
            }
	}
	return null;
    }
    @Override
    public int add(Object obj) {
	Catalogue c = (Catalogue) obj;
	if (c == null) {
            return 0;
	}
	if (!this.catalogues.contains(c)) {
            this.catalogues.add(c);
            return 1;
	}
	return 0;
    }
    @Override
    public int delete(String id) {
	for (Catalogue c : this.catalogues) {
            if (c.getID().equals(id)) {
                this.catalogues.remove(c);
		return 1;
            }
	}
	return 0;
    }
    @Override
    public void update(Object obj) {
	Catalogue c = (Catalogue) obj;
	for (Catalogue c2 : this.catalogues) {
            if (c2.getID().equals(c.getID())) {
		this.catalogues.remove(c2);
		this.catalogues.add(c);
                return ;
            }
	}
    }
}
