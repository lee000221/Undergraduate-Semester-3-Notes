package oodjassignment;

import GUI.Login;
import GUI.AdministratorUI;


/* This is the entrance point of the program */
public class Main {
    //currently logined Administrator & manager
    public static Administrator admin;
    public static Manager manager;
    public static Login login;
    public static AdministratorUI AdministratorUI;
    
    public static void main(String args[]) {
        
        int n;
        //the number of text files read for each name 
	n = ConfigurationUtilities.readAdministrator();
	System.out.println("" + n + " administrator(s) data read");
        
	n = ConfigurationUtilities.readManager();
	System.out.println("" + n + " manager(s) data read");
        
	n = ConfigurationUtilities.readLoginRecord();
	System.out.println("" + n + " login record(s) data read");
        
	n = ConfigurationUtilities.readProduct();
	System.out.println("" + n + " product record(s) data read");
        
	n = ConfigurationUtilities.readSupplier();
	System.out.println("" + n + " supplier record(s) data read");
        
	n = ConfigurationUtilities.readFestival();
	System.out.println("" + n + " festival record(s) data read");
        
	n = ConfigurationUtilities.readCatalogue();
	System.out.println("" + n + " catalogue record(s) data read");
        
        login = new Login();
        AdministratorUI = new AdministratorUI(null);
    }	
}
