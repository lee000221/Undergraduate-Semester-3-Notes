
package oodjassignment;

import java.util.ArrayList;
import oodjassignment.Product.SuppliedProduct;

// A product catalog contains a series of items and could
// can be used in several festivals.
public class Catalogue implements Itemized, textRead,textWrite {
    
    private String ID;
    private String name;
    private ArrayList<Itemized> products; // A catalog consists of a series of items.
    private ArrayList<Festival> festivals; // A catalog can be used for several festivals.
    
    public Catalogue(){
        this.ID = Catalogue.GenerateCatalogueID();
        this.name = "";
        this.products = new ArrayList();
        this.festivals = new ArrayList();
    }
    private static String GenerateCatalogueID(){
        // Auto generate ID
        String id = "0";
        if (ConfigurationUtilities.catalogues != null){
            for (Catalogue c: ConfigurationUtilities.catalogues){
                if(Integer.parseInt(c.getID()) > Integer.parseInt(id)){
                    id = c.getID();
                }
            }
        }    
        id = "" + (Integer.parseInt(id)+1);
        return id;
    }
        
    public String getID(){
        return ID;
    }
    public void setID(String iD){
        ID = iD;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    
    public ArrayList<Festival> getFestival(){
        return festivals;
    }
    public void setFestival(ArrayList<Festival> festival){
        this.festivals=festival;
    }
    public boolean addFestival (Festival f){
        if(!this.festivals.contains(f)){
            this.festivals.add((Festival)f.clone());
            return true;
        }
        return false;
    }
    public boolean removeFestival(Festival f) {
	if (this.festivals.contains(f)) {
            this.festivals.remove(f);
            return true;
	}
	else {
            return false;
	}
    }	
    public ArrayList<Itemized> getProducts() {
        return products;
    }
    public void setProducts(ArrayList<Itemized> ps) {
	this.products = ps;
    }
    public boolean addProduct(Product i) {
	if (!this.products.contains(i)) {
            this.products.add((Product)i.clone());
            return true;
	}
        return false;
    }
    public boolean removeProduct(Product i) {
	if (this.products.contains(i)) {
            this.products.remove(i);
            return true;
	}
	else {
            return true;
	}
    }
    public String toString() {
	return this.getID() + ", " + this.getName() ;
    }    
    public boolean equals (Object o){
        Catalogue c = (Catalogue) o;
        return this.getID().equals(c.getID());
    }
    public Object clone() {
	Catalogue p = new Catalogue();
	p.setID(this.ID);
        p.setName(this.name);
	for (Festival f : this.festivals) {
            p.addFestival(f);
	}
	for (Itemized pd : this.products) {
            p.addProduct((Product)pd);
	}
	return p;
    }
    @Override
    public String writeText() {
        // return a  string with all data member fields
	ArrayList<String> ss = new ArrayList();
	ss.add(this.getID());
	ss.add(this.getName());	
	// festival ID
	ss.add(""+this.festivals.size());
	for (Festival f : this.festivals) {
            ss.add(f.getID());
	}			
	// product ID
	ss.add(""+this.products.size());
	for (Itemized p : this.products) {
            ss.add(p.getID());
	}
	return  String.join(ConfigurationUtilities.fieldDelimeter, ss);
    }
    @Override
    public textRead readText(String txt) {
	String ss[] = txt.split(ConfigurationUtilities.fieldDelimeter);	
        
	this.setID(ss[0].trim());
	this.setName(ss[1].trim());
        
	FestivalManage fm = new FestivalManage();
	this.festivals.clear();
	int n = Integer.parseInt(ss[2].trim());
	for (int i = 0; i < n; i++) {
            this.addFestival((Festival)fm.find(ss[3+i]));
	}
	ProductManage pm = new ProductManage();
	this.products.clear();
	int n2 = Integer.parseInt(ss[3+n].trim());
	for (int i = 0; i < n2; i++) {
            this.addProduct((Product)pm.find(ss[4+n+i]));
	}
	return (textRead)this.clone();	
    }
}    
