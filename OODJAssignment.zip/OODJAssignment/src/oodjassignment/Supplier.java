
package oodjassignment;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeMap;

// A supplier could supply a series of products.
public class Supplier implements textRead, textWrite{
    private String ID;
    private String Name;
    private String Country;
    private String Address;
    private String PhoneNumber;
    private String Email;
    private TreeMap<String, Supplier> suppliers; 

    public Supplier(){
	this.ID = Supplier.GenerateSupplierID();    
	this.suppliers = new TreeMap<String, Supplier>();
    
    }
    public Supplier(String ID, String Name,String Country,String Address,String PhoneNumber, String Email){
        this.ID = Supplier.GenerateSupplierID();
        this.Name = Name;
        this.Country=Country;
        this.Address = Address;
        this.PhoneNumber = PhoneNumber;
        this.Email=Email;
    }
    private static String GenerateSupplierID() {
	// Auto generate ID
	String id = "0";
	if (ConfigurationUtilities.suppliers != null) {
            for (Supplier p : ConfigurationUtilities.suppliers) {
		if (Integer.parseInt(p.getID()) > Integer.parseInt(id)) {
                    id = p.getID();
		}
            }
	}
	id = "" + (Integer.parseInt(id) + 1);
	return id;
    }
    public void setID(String id){
        ID=id;
    }
    public String getID(){
        return ID;
    }
    public void setName(String name){
        Name=name;
    }
    public String getName(){
        return Name;
    }
    public void setCountry(String cr){
        Country=cr;
    }
    public String getCountry(){
        return Country;
    }
    public void setAddress(String add){
        Address=add;
    }
    public String getAddress(){
        return Address;
    }
    public void setPhoneNumber(String pn){
        PhoneNumber=pn;
    }
    public String getPhoneNumber(){
        return PhoneNumber;
    }
    public void setEmail(String email){
        Email=email;
    }
    public String getEmail(){
        return Email;
    }
    public Object clone(){
        Supplier s = new Supplier();
        s.setID(ID);
        s.setName(Name);
        s.setCountry(Country);
        s.setAddress(Address);
        s.setPhoneNumber(PhoneNumber);
        s.setEmail(Email);
        return s;
    }
    public String toString(){
        return "ID:" + this.getID() + ",Name:" +this.getName();
    }
    public boolean equals(Object o){
        Supplier s = (Supplier)o;
        if (s == null) {
            return false;
	}
	return s.getID().equals(this.getID());    
    }
    
    // return a colon separated string with all data member fields
    @Override
    public String writeText(){
        String[] ss = {this.ID, this.Name, this.Country, this.Address, this.PhoneNumber, this.Email};
        return String.join(ConfigurationUtilities.fieldDelimeter, ss);
    }
    @Override
    public textRead readText(String txt){
        String[] ss = txt.split(ConfigurationUtilities.fieldDelimeter);
        
        this.setID(ss[0]);
        this.setName(ss[1]);
        this.setCountry(ss[2]);
        this.setAddress(ss[3]);
        this.setPhoneNumber(ss[4]);
        this.setEmail(ss[5]);
        return (textRead) this.clone();
    }
}
