
package oodjassignment;

import java.util.Arrays;
import java.util.Date;
// A user can login to the system by unique id and password, and has a name.
// Sample concrete sub-classes include Manager and Administrator.
public abstract class UserValidation {
    protected String id;
    protected String name;
    protected String password;
    // login state
    protected boolean login = false;
    public UserValidation(){}
    public UserValidation(String id, String name, String password){
        this.id = id;
        this.name = name;
        this.password = password;
    }
    public String getid(){
        return id;
    }
    public void setid(String id){
        this.id = id;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getPassword(){
        return password;
    }
    public void setPassword(String password){
        this.password = password;
    }
    public boolean equals(Object o){
        UserValidation u = (UserValidation)o;
	if (u==null) return false;
        return this.getid().equals(u.getid());
    }
    public String toString(){
        return "ID:" + this.getid() + ", Name" + this.getName() +", Password" + this.getPassword();
    }
    public boolean login(String id, char [] pw1){
        //chenck password and id
        if(this.id.equals(id) && Arrays.equals(pw1, this.password.toCharArray())){
            this.login = true;
            return true;
        }
        else{
            this.login = false;
            return false;
        }
    }
    public void logout(){
        //write login/logout records
        this.login = false;
    }
}
