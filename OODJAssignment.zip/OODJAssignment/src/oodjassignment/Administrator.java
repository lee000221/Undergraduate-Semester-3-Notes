
package oodjassignment;

import java.io.FileOutputStream;

public class Administrator extends UserValidation implements textRead, textWrite{
    private String title;
    private String phone;
    private String email;
    public String getTitle(){
        return title;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public String getPhone(){
        return phone;
    }
    public void setPhone(String phone){
        this.phone = phone;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String Email){
        this.email = email;
    }
    
    public Object Clone(){
        Administrator a = new Administrator();
        a.setid(this.getid());
        a.setPassword(this.getPassword());
        a.setName(this.getName());
        a.setTitle(this.getTitle());
        a.setEmail(this.getEmail());
        a.setPhone(this.getPhone());
        return a;
    }
    @Override
    public textRead readText(String txt){
        String[] ss = txt.split(ConfigurationUtilities.fieldDelimeter);
        this.setid(ss[0].trim());
        this.setPassword(ss[1].trim());
        this.setName(ss[2].trim());
        this.setTitle(ss[3].trim());
        this.setEmail(ss[4].trim());
        this.setPhone(ss[5].trim());
        return (textRead)this.Clone();
    }
    
    @Override
    public String writeText(){
        String[] ss = {this.getid(),""+this.getPassword(),""+this.getName(),""+this.getTitle(),""+this.getEmail(),""+this.getPhone()};
        return String.join(ConfigurationUtilities.fieldDelimeter, ss);
    }
}
