
package oodjassignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ConfigurationUtilities {
    private static String dataStoreDir = "productdata";
    private static String managerDataFile = "Manager.txt";
    private static String administratorDataFile = "administrator.txt";
    private static String productDataFile ="product.txt";
    private static String supplierDataFile = "supplier.txt";
    private static String loginDataRecordFile = "login.txt";
    private static String catalogueDataFile = "catalogue.txt";
    private static String festivalDataFile = "festival.txt";
    
    public static final String fieldDelimeter=",";
    
    public static ArrayList<Administrator> administrators ;
    public static ArrayList<Manager> managers;
    public static ArrayList<LoginRecord> loginrecords;
    public static ArrayList<Product> products;
    public static ArrayList<Supplier> suppliers;
    public static ArrayList<Festival> festivals;
    public static ArrayList<Catalogue> catalogues;
    
    public static void setDataStoreDirectory(String DIR){
        ConfigurationUtilities.dataStoreDir = DIR;
    }
    public static String getDataStoreDirectory(){
        return dataStoreDir;
    }
    public static void setManagerData(String MD){
        ConfigurationUtilities.managerDataFile = MD;
    }
    public static String getManagerData(){
        return managerDataFile;
    }
    public static void setAdministratorData(String AD){
        ConfigurationUtilities.administratorDataFile = AD;
    }
    public static String getAdministratorData(){
        return administratorDataFile;
    }
    public static void setProductData(String PD){
        ConfigurationUtilities.productDataFile = PD;
    }
    public static String getProductData(){
        return productDataFile;
    }
    public static void setSupplierData(String SD){
        ConfigurationUtilities.supplierDataFile = SD;
    }
    public static String getSupplierData(){
        return supplierDataFile;
    }
    public static void setFestivalData(String FD){
        ConfigurationUtilities.festivalDataFile = FD;
    }
    public static String getFestivalData(){
        return festivalDataFile;
    }
    
    public static int readAdministrator(){
        Administrator admin = new Administrator();
        ConfigurationUtilities.administrators = (ArrayList<Administrator>) ConfigurationUtilities.readFromTextFile(admin, ConfigurationUtilities.administratorDataFile);
        return ConfigurationUtilities.administrators.size();
    }
    public static int writeAdministrator(){
        ConfigurationUtilities.writeText(ConfigurationUtilities.administrators, ConfigurationUtilities.administratorDataFile);
        return ConfigurationUtilities.administrators.size();
    }
    public static int readManager(){
        Manager managers = new Manager();
        ConfigurationUtilities.managers = (ArrayList<Manager>) ConfigurationUtilities.readFromTextFile(managers, ConfigurationUtilities.managerDataFile);
        return ConfigurationUtilities.managers.size();
    }
    public static int writeManager(){
        ConfigurationUtilities.writeText(ConfigurationUtilities.managers, ConfigurationUtilities.managerDataFile);
        return ConfigurationUtilities.managers.size();
    }
    public static int readFestival(){
	Festival f = new Festival();
	ConfigurationUtilities.festivals = (ArrayList<Festival>) ConfigurationUtilities.readFromTextFile(f, ConfigurationUtilities.festivalDataFile);
	return ConfigurationUtilities.festivals.size();
    }
    public static int writeFestival(){	
	ConfigurationUtilities.writeText(ConfigurationUtilities.festivals, ConfigurationUtilities.festivalDataFile);
	return ConfigurationUtilities.festivals.size();
    }
    public static int readCatalogue(){
	Catalogue f = new Catalogue();
	ConfigurationUtilities.catalogues = (ArrayList<Catalogue>) ConfigurationUtilities.readFromTextFile(f, ConfigurationUtilities.catalogueDataFile);		
        return ConfigurationUtilities.catalogues.size();
    }
    public static int writeCatalogue(){	
	ConfigurationUtilities.writeText(ConfigurationUtilities.catalogues, ConfigurationUtilities.catalogueDataFile);
	return ConfigurationUtilities.catalogues.size();
    }
    public static int readLoginRecord(){
	LoginRecord r = new LoginRecord();
	ConfigurationUtilities.loginrecords = (ArrayList<LoginRecord>) ConfigurationUtilities.readFromTextFile(r, ConfigurationUtilities.loginDataRecordFile);
	return ConfigurationUtilities.loginrecords.size();
    }
    public static int writeLoginRecord(){	
	ConfigurationUtilities.writeText(ConfigurationUtilities.loginrecords, ConfigurationUtilities.loginDataRecordFile);
	return ConfigurationUtilities.loginrecords.size();
    }
    public static int readProduct(){
	Product p = new Product();
	ConfigurationUtilities.products = (ArrayList<Product>) ConfigurationUtilities.readFromTextFile(p, ConfigurationUtilities.productDataFile);
	return ConfigurationUtilities.products.size();
    }
    public static int writeProduct(){	
	ConfigurationUtilities.writeText(ConfigurationUtilities.products, ConfigurationUtilities.productDataFile);
	return ConfigurationUtilities.products.size();
    }
    public static int readSupplier(){
	Supplier p = new Supplier();
	ConfigurationUtilities.suppliers = (ArrayList<Supplier>) ConfigurationUtilities.readFromTextFile(p, ConfigurationUtilities.supplierDataFile);
        return ConfigurationUtilities.suppliers.size();
    }
    public static int writeSupplier(){	
	ConfigurationUtilities.writeText(ConfigurationUtilities.suppliers, ConfigurationUtilities.supplierDataFile);
	return ConfigurationUtilities.suppliers.size();
    }
    
    public static int writeText(ArrayList<? extends textWrite>tobjs, String filename) {
        int count = 0;
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
            for (textWrite obj : tobjs){
                String txt = obj.writeText();
                bw.write(txt + "\n");
                count ++;
            }
            bw.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        return count;
    }
    public static ArrayList<? extends textRead> readFromTextFile(textRead tr, String filename){
        ArrayList<textRead> tobjs = new ArrayList<textRead>(); 
        try{
            Scanner br = new Scanner(new FileReader(filename));
            while (br.hasNext()){
                String ln=br.nextLine();
                tobjs.add(tr.readText(ln));
                if (tr instanceof Supplier){
                }
            }
            br.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        return tobjs;
    }
}
