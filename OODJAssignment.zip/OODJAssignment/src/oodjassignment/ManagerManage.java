package oodjassignment;

import java.util.ArrayList;

public class ManagerManage implements Manageable {
    private ArrayList<Manager> managers;
    public ManagerManage() {
	this.managers = ConfigurationUtilities.managers;
    }
	
    @Override
    public Object find(String id) {
	for (Manager m : managers) {
            if (m.getid().equals(id)) {
		return m;
            }
	}
	return null;
    }
    @Override
    public int add(Object obj) {
        Manager m = (Manager)obj;
	if (m==null) {
            System.out.println("Can not change Object to Manager");
            return 0;
	}
	if (this.find(m.getid()) != null) {
            System.out.println("Manager already exists");
            return 0;
	}
	else {
            this.managers.add(m);
            return 1;
	}
    }
    @Override
    public int delete(String id) {
	for (Manager m : managers) {
            if (m.getid().equals(id)) {
		this.managers.remove(m);
		return 1;
            }
	}
	return 0;
    }
    @Override
    public void update(Object obj) {
        Manager m = (Manager)obj;
	if (m==null) {
            System.out.println("Can not change Object to Manager");
	}
	if (this.find(m.getid()) != null) {
            Manager mold = (Manager)this.find(m.getid());
            this.managers.remove(mold);
            this.managers.add(m);
	}
	else {			
            System.out.println("Update failed. Manager not found");
	}
    }
}
