package oodjassignment;

// A manager could manage products and suppliers.
public class Manager extends UserValidation implements textRead, textWrite {
    private String ID;
    private String name;
    private String department;
    private ProductManage productManage = new ProductManage();
    private SupplierManage supplierManage = new SupplierManage();
	
    public Manager() {
	super(Manager.GenerateManagerUID(), "", "");
	this.department = "";
	this.supplierManage.attachProducManage(this.productManage);
    }
    public Manager(String dept, String name, String pwd) {
	super(Manager.GenerateManagerUID(), name, pwd);
	this.department = dept;
	this.supplierManage.attachProducManage(this.productManage);
    }
    private static String GenerateManagerUID() {
	// Auto generate UID
	String uid = "0";
	if (ConfigurationUtilities.managers != null) {
            for (Manager m : ConfigurationUtilities.managers) {
		if (Integer.parseInt(m.getid()) > Integer.parseInt(uid)) {
                    uid = m.getid();
		}
            }
	}
	uid = "" + (Integer.parseInt(uid) + 1);
	return uid;
    }
    public String getDepartment() {
	return this.department;
    }
    public void setDepartment(String dept) {
	this.department = dept;
    }
    public String toString(){
        return "ID:" + this.getid() + ",Name:" +this.getName() + ",Password:"+this.password;
    }

    @Override
    public String writeText() {
        // return a colon separated string with all data member fields
	String ss[] = { this.getid(), this.getPassword(), this.getName(), this.getDepartment() };
	String r = String.join(ConfigurationUtilities.fieldDelimeter, ss);
	return r;
    }
    @Override
    public textRead readText(String txt) {
	String ss[] = txt.split(ConfigurationUtilities.fieldDelimeter);
	this.setid(ss[0].trim());
	this.setPassword(ss[1].trim());
	this.setName(ss[2].trim());
	this.setDepartment(ss[3].trim());
	return (textRead)this.clone();		
    }
    @Override
    public Object clone() {
	Manager m = new Manager();
	m.setid(this.getid().trim());
	m.setPassword(this.getPassword().trim());
	m.setName(this.getName().trim());
	m.setDepartment(this.getDepartment().trim());
	return m;
    }
	
}
