package oodjassignment;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
// The class manages suppliers.
public class SupplierManage implements Manageable {
    private ArrayList<Supplier> suppliers;
    private ProductManage productManage;
    public SupplierManage() {
	this.suppliers = ConfigurationUtilities.suppliers;
    }
    public ArrayList<Supplier> getSuppliers() {
	return this.suppliers;
    }
    public String[] getAllSupplierNames() {
	String[] names = new String[this.suppliers.size()];
	for (int i = 0; i < this.suppliers.size(); i++) {
            names[i] = this.suppliers.get(i).getName();
	}
	return names;
    }
    public Supplier findSupplierByName(String name) {
	for (Supplier s : this.suppliers) {
            if (s.getName().equals(name)) {
		return s;
            }
	}
	return null;
    }
    public void attachProducManage(ProductManage pm) {
	this.productManage = pm;
    }
    @Override
    public Object find(String id) {
	for (Supplier s : this.suppliers) {
            if (s.getID().equals(id)) {
		return s;
            }
	}
	return null;
    }
    @Override
    public int add(Object obj) {
	Supplier s = (Supplier) obj;
	if (s != null) {
            this.suppliers.add(s);
            return 1;
	}
	else {
            return 0;
	}
    }
    @Override
    public int delete(String id) {
        Supplier s = (Supplier) this.find(id);
	if (s != null) {
            this.suppliers.remove(s);
            return 1;
	}
	return 0;
    }
    @Override
    public void update(Object obj) {
        Supplier s = (Supplier) obj;
	if (s != null && this.find(s.getID()) != null) {
            this.suppliers.remove(s);
            this.suppliers.add(s);
            return;
        }
    }
}
