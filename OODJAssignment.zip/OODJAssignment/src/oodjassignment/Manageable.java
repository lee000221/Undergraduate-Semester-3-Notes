
package oodjassignment;

public interface Manageable {
    public Object find(String id);
    public int add(Object obj);
    public int delete(String id);
    public void update(Object obj);
}
