package oodjassignment;
import java.util.Date;

/**
 * Represent a Festival.
 * 
 *
 */
public class Festival implements textRead, textWrite{
    private String id;
    private String date;
    private String name;

    public Festival() {
	this.id = Festival.GenerateFestivalID() +"";
	this.name = "";
	this.date  = "";
    }
    private static String GenerateFestivalID() {
        // Auto generate UID
        String id = "0";
	if (ConfigurationUtilities.festivals != null) {
            for (Festival f : ConfigurationUtilities.festivals) {
		if (Integer.parseInt(f.getID()) > Integer.parseInt(id)) {
                    id = f.getID();
		}
            }
	}
	id = "" + (Integer.parseInt(id) + 1);
	return id;
    }
    public String getID() {
	return id;
    }
    public void setID(String id) {
	this.id = id;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
	this.date = date;
    }
    public String getName() {
	return name;
    }
    public void setName(String name) {
	this.name = name;
    }
    
    public boolean equals(Object o) {
	return this.id.equals( ((Festival)o).getID());
    }
    public String toString() {
	return this.id + this.getName() + ", " + this.getDate();
    }
    
    public Object clone() {
	Festival f = new Festival();
	f.setID(this.getID());
	f.setName(this.getName());
	f.setDate(this.getDate());
	return f;
    }
    //write data to festival.txt
    @Override
    public String writeText() {
        String[] ss = {this.id, this.name, this.date};
        return String.join(ConfigurationUtilities.fieldDelimeter, ss);
	}
    @Override
    //read data from festival.txt
    public textRead readText(String txt) {
	String ss[] = txt.split(ConfigurationUtilities.fieldDelimeter);
        this.setID(ss[0].trim());
        this.setName(ss[1].trim());
        this.setDate(ss[2].trim());
	return (textRead)this.clone();	
    }
}
